package com.cz.base.frame.cached;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.data.redis.connection.Message;
import org.springframework.data.redis.core.RedisKeyExpiredEvent;
import org.springframework.data.redis.listener.KeyExpirationEventMessageListener;
import org.springframework.data.redis.listener.RedisMessageListenerContainer;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * Created by Administrator on 2019/4/2.
 */
@Component
public class RedisKeyExpirationListener extends KeyExpirationEventMessageListener {


    public Logger logger = LoggerFactory.getLogger(getClass());

    @Resource
    private RedisKeyExpirationDelegateService redisKeyExpirationDelegateService;

    public RedisKeyExpirationListener(RedisMessageListenerContainer listenerContainer) {
        super(listenerContainer);
    }

    @Override
    protected void doRegister(RedisMessageListenerContainer listenerContainer) {
        super.doRegister(listenerContainer);
    }

    @Override
    public void onMessage(Message message, byte[] pattern) {
        try {
            redisKeyExpirationDelegateService.onMessage(message, pattern);
        }catch (Exception e){
            // 记录错误日志
            logger.error("redis超时回调错误" + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    protected void doHandleMessage(Message message){

    }

    @Override
    protected void publishEvent(RedisKeyExpiredEvent event) {
        super.publishEvent(event);
    }

    @Override
    public void setApplicationEventPublisher(ApplicationEventPublisher applicationEventPublisher) {
        super.setApplicationEventPublisher(applicationEventPublisher);
    }
}

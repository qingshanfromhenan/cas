package com.cz.base.frame.aspect;

import com.cz.base.frame.entity.ConfigBean;
import com.cz.base.frame.util.*;
import org.aopalliance.intercept.Joinpoint;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * 对app端返回数据进行加密
 * @author Michael
 *
 */
@Component
@Aspect
public class SecurityAspect {

	@Resource
	private CacheManager cacheManager ;

	//加密使用的私钥
	private String privateKey = "";
	// 验签使用的公钥
	private String publicKey = "" ;


	@Pointcut("@annotation(com.cz.base.frame.annotation.SecurityApi)")
	public void securityAop(){}



	@Before("securityAop() && args(joinpoint)")
	public void  securityBefore(Joinpoint joinpoint){

	}

	@AfterReturning(pointcut = "securityAop()",
			returning = "returnDatas")
	public void securityAfter(ReturnDatas returnDatas){

		if(returnDatas != null && returnDatas.getData() != null){
			//返回数据
			String result = JsonUtils.writeValueAsString(returnDatas.getData()) ;

//			String encodeData = null;
//			try {
//				encodeData = Des3.encode(result);
//			} catch (Exception e) {
////				//  Auto-generated catch block
//				e.printStackTrace();
//				returnDatas.setStatus(ReturnDatas.WARNING);
//				returnDatas.setMessage("加密失败！");
//			}
//			returnDatas.setData(encodeData);
			returnDatas.setData(result);
		}
	}

	@Autowired
	HttpServletRequest request;

//	@Around("securityAop()")
//	public Object around(ProceedingJoinPoint proceedingJoinPoint){
//		Object object = null ;
//		Object[] args = proceedingJoinPoint.getArgs() ;
//
//		Map<String,String[]> paramMap = new HashMap(request.getParameterMap()) ;
//
//		if(!paramMap.containsKey("signCode")){  //说明是非法请求
//			return new ReturnDatas(ReturnDatas.ERROR, "非法请求") ;
//		}else {
//			try {
//				String[] sign = (String[])paramMap.get("signCode") ;
//				String singStr = StringUtils.join(sign) ;
//				singStr = singStr.replace("~2B~","+") ;
//
//				//获取私钥 和 公钥
//				Cache cacheConfig = cacheManager.getCache(GlobalStatic.cacheKey) ;
//				ConfigBean configBean = cacheConfig.get(GlobalStatic.configCache,ConfigBean.class);
//				privateKey = configBean.getApiRSAPriKey() ;
//				publicKey  = configBean.getApiRSASignPubKey() ;
//
//				//解密
////				String params= SecureRSA.decrypt(sign[0], privateKey, "UTF-8") ;   //私钥
//				String params= SecureRSA.decrypt(singStr, privateKey, "UTF-8") ;   //私钥
//				JSONObject json = JSONObject.fromObject(params) ;
//				//验证时间戳，防止爬虫请求
//				if(!json.containsKey("T")){
//					return new ReturnDatas(ReturnDatas.ERROR, "非法请求") ;
//				}else {
//
//					Long T = json.getLong("T") ;
//					Date legalTime = org.apache.commons.lang3.time.DateUtils.addMinutes(new Date(), -10) ;
//					/*if(T < Double.valueOf(DateFormatUtils.format(legalTime, "yyyyMMddHHmmss"))) {  //说明请求时间差超过10分钟，不是合法的
//						return new ReturnDatas(ReturnDatas.ERROR, "通讯超时") ;
//					}*/
//					//校验token时间
//					if (json.containsKey("token") && StringUtils.isNotBlank(json.getString("token") )){
//						String token = json.getString("token") ;
//						if (json.containsKey("sessionId") && StringUtils.isNotBlank(json.getString("sessionId") )){
//							Cache cache = cacheManager.getCache(GlobalStatic.tokenCacheKey);
//							String userId = json.getString("sessionId") ;
//							Token cacheToken = cache.get("token_"+userId, Token.class) ;
//							if (cacheToken == null){
//								return new ReturnDatas(ReturnDatas.LOGIN, "请登录") ;
//							}else {
//								if (!token.equals(cacheToken.getToken())){
//									return new ReturnDatas(ReturnDatas.LOGIN, "非法请求") ;
//								}
//								Date expired = cacheToken.getExpired() ;  //失效时间
//								if (expired.before(new Date())){  //已失效
//									cache.evict("token_"+userId);
//									return new ReturnDatas(ReturnDatas.LOGIN, "请登录") ;
//								}else{  //代表正常用户，此时要延长失效时间
//									//更新最后操作时间
//									cacheToken.setLastOperate(new Date());
//
//									cacheToken.setExpired(new Date(cacheToken.getLastOperate().getTime() + Integer.valueOf(configBean.getTokenTimeout()) * 60 * 1000));
//									//更新token缓存
//									cache.put("token_"+userId,cacheToken);
//								}
//							}
//						}else {
//							return new ReturnDatas(ReturnDatas.LOGIN, "请登录") ;
//						}
//					}
//
//					//取得密文
//					String ciphertext = json.getString("sign") ;
//					// 解密后需要验签
//					paramMap.remove("signCode") ;
//					paramMap.remove("T");
//					Map<String, Object> sortMap = new TreeMap<String, Object>();  // 使用sortedMap进行key排序
//					sortMap.putAll(paramMap);
//
//					StringBuffer plaintext = new StringBuffer() ;  // 明文数据
//					Iterator iterText = sortMap.entrySet().iterator();
//					Map.Entry entryText ;
//					while (iterText.hasNext()){
//						entryText = (Map.Entry) iterText.next();
//						Object key = entryText.getKey();
//						Object val = entryText.getValue();
//						plaintext.append(key + "=" + ((String[])val)[0]);
//						if (iterText.hasNext()){
//							plaintext.append("&");
//						}
//					}
//					if(! AlipaySignature.rsaCheckContent(plaintext.toString(),ciphertext,publicKey,"utf-8")){
////					if(! AlipaySignature.rsa256CheckContent(plaintext.toString(),ciphertext,publicKey,"utf-8")){
//						return new ReturnDatas(ReturnDatas.ERROR, "验签失败") ;
//					}
//
//
//					try {
//						object = proceedingJoinPoint.proceed() ;
//					} catch (Throwable e) {
//						// 发送警告邮件！！
//						String message = "" ;
//						Class superClass = e.getClass().getSuperclass() ;
//						if (e instanceof Exception && e.getCause() == null && superClass == Throwable.class  ){
//							message = e.getMessage() ;
//						}else {   // 抛出error以及系统异常
//							StringBuffer paramSB = new StringBuffer() ;
//							Iterator iter = paramMap.entrySet().iterator();
//							Map.Entry entry ;
//							while (iter.hasNext()){
//								entry = (Map.Entry) iter.next();
//								Object key = entry.getKey();
//								Object val = entry.getValue();
//								paramSB.append("<div style='text-indent:15px;'><span style='color:red ;'>"+key.toString() + "</span>:" + ((String[])val)[0] + "</div><br>") ;
//							}
//
//							StackTraceElement[] elems = e.getStackTrace();
//							StringBuffer exceptionInfo = new StringBuffer("<html><body>") ;
//							exceptionInfo.append("<h3>请求url：</h3>") ;
//							exceptionInfo.append(request.getRequestURI()) ;
//							exceptionInfo.append("<h3>入参：</h3>") ;
//							exceptionInfo.append(paramSB.toString()) ;
//							exceptionInfo.append("<h3>" + e.toString() + "</h3>") ;
//							for (StackTraceElement element:
//									elems) {
//								exceptionInfo.append("<div style='text-indent:15px;'>" +
//										element.getClassName() +"."+
//										element.getMethodName() +
//										"(<span style='color:red ;'>" +
//										element.getFileName() +":"+element.getLineNumber() + "</span>)" +
//										"</div><br>") ;
//							}
//							exceptionInfo.append("</body></html>") ;
//
//							MailThreadClazz thread = new MailThreadClazz(configBean.getAlarmEmailSubject() + "(时间："+ DateFormatUtils.format(new Date(),"yyyy-MM-dd HH:mm:ss")+")",exceptionInfo.toString()) ;
//							thread.start();
//
//							e.printStackTrace();
//							message = MessageUtils.INTERNAL_ERROR;
//						}
//						return new ReturnDatas(ReturnDatas.ERROR, message) ;
//					}
//
//				}
//
//			}catch ( BadPaddingException e){
//				e.printStackTrace();
//				return new ReturnDatas(ReturnDatas.ERROR, "非法请求") ;
//			}catch (Throwable e) {
//				e.printStackTrace();
//				return new ReturnDatas(ReturnDatas.ERROR, "请求出错") ;
//			}
//		}
//
//		return object ;
//	}


	@Around("securityAop()")
	public Object around(ProceedingJoinPoint proceedingJoinPoint){
		Object object = null ;
		Object[] args = proceedingJoinPoint.getArgs() ;

		Map<String,String[]> paramMap = new HashMap(request.getParameterMap()) ;
		Cache cacheConfig = cacheManager.getCache(GlobalStatic.cacheKey) ;
		ConfigBean configBean = cacheConfig.get(GlobalStatic.configCache,ConfigBean.class);
		try {
			object = proceedingJoinPoint.proceed() ;
		} catch (Throwable e) {
			// 发送警告邮件！！
			String message = "" ;
			Class superClass = e.getClass().getSuperclass() ;
			if (e instanceof Exception && e.getCause() == null && superClass == Throwable.class  ){
				message = e.getMessage() ;
			}else {   // 抛出error以及系统异常
				StringBuffer paramSB = new StringBuffer() ;
				Iterator iter = paramMap.entrySet().iterator();
				Map.Entry entry ;
				while (iter.hasNext()){
					entry = (Map.Entry) iter.next();
					Object key = entry.getKey();
					Object val = entry.getValue();
					paramSB.append("<div style='text-indent:15px;'><span style='color:red ;'>"+key.toString() + "</span>:" + ((String[])val)[0] + "</div><br>") ;
				}

				StackTraceElement[] elems = e.getStackTrace();
				StringBuffer exceptionInfo = new StringBuffer("<html><body>") ;
				exceptionInfo.append("<h3>请求url：</h3>") ;
				exceptionInfo.append(request.getRequestURI()) ;
				exceptionInfo.append("<h3>入参：</h3>") ;
				exceptionInfo.append(paramSB.toString()) ;
				exceptionInfo.append("<h3>" + e.toString() + "</h3>") ;
				for (StackTraceElement element:
						elems) {
					exceptionInfo.append("<div style='text-indent:15px;'>" +
							element.getClassName() +"."+
							element.getMethodName() +
							"(<span style='color:red ;'>" +
							element.getFileName() +":"+element.getLineNumber() + "</span>)" +
							"</div><br>") ;
				}
				exceptionInfo.append("</body></html>") ;

				MailThreadClazz thread = new MailThreadClazz(configBean.getAlarmEmailSubject() + "(时间："+ DateFormatUtils.format(new Date(),"yyyy-MM-dd HH:mm:ss")+")",exceptionInfo.toString()) ;
				thread.start();

				e.printStackTrace();
				message = MessageUtils.INTERNAL_ERROR;
			}
			return new ReturnDatas(ReturnDatas.ERROR, message) ;
		}

		return object ;
	}


	/**
	 * 一个多线程的内部类，用来执行邮件的发送
	 */
	private  class MailThreadClazz extends  Thread{
		public MailThreadClazz(String theme,String content) {
			super();
			this.content= content ;
			this.theme = theme ;
		}

		public String theme ;
		public String content;

		public void run(){
			try {
//				MailUtil.sendHtmlMail(theme,content) ;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

//	@Test
//	public void text(){
//		try {
////			String privatekey = "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAKPCzhbeoIUjPGeN6sMpicRYedeWmLrM9by9GqKMLn6XQ8EAn4/v0dTXTyVJ8ps6jEJxvaSJojf2e/qjObAQdDkPnAXihEO/MV4qCrIt68IiTRjPPjCqoOZIwcI5iXFwI0etHn4KH2UYlHFxINZQ3Ex9oXffQhNfDn5WOVxZDSA/AgMBAAECgYBTenqULeil9dBU+YMy+XnBHVj/DUXN861RCRUKx2rsHS/ssuSj+xx740X1PDzv5Gibdl+2AHMxE/UfTxWZKsoTevpd2ddsnOlmH4gQr69U/qZcECmVfIkQYiRsGbxLYdyPWpFE8Ntwj8rc7A26iZfyO6ta2jbAWDOtWbxsd5FsAQJBAN2a2ys2Vxealge9rzokPMDSuCMcidgLuWinVvCwtcat7XgOY64rShyfQOI9mfQ1iQRZQkzmA8vkm62iUBWfge0CQQC9LZreIT8ihB9cTpqOQxJFEbaRmvzYO9HQ/GTsVnyoK+cGtprVVHZcmxmT9Jhh54f7gegK3k83DmEVokeyR5VbAkEA25z/3s83eFjmnj1JTmFjI+SwP3ukz8qusBxGeLlnK8JqODRqbMzR4ZOhhZRu4im74+dhYTwCPyoLbgQRQZyV8QJAYXudoTdKnFOvAVbz57kCMhtFk9Rk1FxG60UUEIEkrVgqLVhtgt6KO4Ak9wwEdfbkKKMxWmBiO4GqX4aHIYQnnwJAJz2JcdRvQJYUDvd9qTvoJjS0pOJ74+5mxfr5/ZPjz57h3K1jch2AEfeRhbpcOF/9KS2fwM1TUS26S7hIelCqkg==" ;
////			String signStr = "";
////			String params= SecureRSA.decrypt(signStr, privatekey, "UTF-8") ;   //私钥
////			System.out.println(params);
//
//
//			String publickey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCf1YgL9RXRDL3BzOHB0o0SnsRmmJPgzSIL6EPguMalMD1f1j5TgsCp+wIzLkFLQYzMslvXORoRPS5Hl3iQaaktMekgSPNMrxuHmvpiouZRcw3xhBOa+Ju+UcWJZfiWScRzVIZ/4WI35xUpp7zzos+azOXjeLi8MS+TMmmQ5rMQEwIDAQAB" ;
//			JSONObject json = JSONObject.fromObject("{\"sign\":\"RtK3l70emV65XpvuD0WSVHkcpRTgi3SjaZNsEWunvG0NUs9mCHhgfjeqoMlgzKGbBBBZbn5H1vRKIzGCws3ZQUc93G1zYV4/ScqqzZYI9b06pfAhLBgcK4O6+7IvfZCXbtvJXnShpUhMCnMZ8+k/U1iZeEYCHZuW4cWmQPAJHQ==\",\"T\":1545362825701,\"itemId\":\"337\",\"level\":\"0\",\"userId\":\"25\",\"type\":\"6\"}") ;
//			String sign = json.getString("sign") ;
//			sign = sign.replace("~2B~","+") ;
//			System.out.println("js签名："+ sign);
//			json.remove("sign") ;
//			json.remove("T") ;
//			StringBuffer plaintext = new StringBuffer() ;  // 明文数据
//			Set set = ((Map)json).entrySet() ;
//			Iterator iterText = ((Map)json).entrySet().iterator();
//			Map.Entry entryText ;
//			while (iterText.hasNext()){
//				entryText = (Map.Entry) iterText.next();
//				Object key = entryText.getKey();
//				Object val = entryText.getValue();
//				plaintext.append(key + "=" + val);
//				if (iterText.hasNext()){
//					plaintext.append("&");
//				}
//			}
//
////			System.out.println("原数据："+plaintext);
//			String signContent = AlipaySignature.getSignContent(json);
//			System.out.println("原数据："+signContent) ;
//
//			String prikey = "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAJ/ViAv1FdEMvcHM4cHSjRKexGaYk+DNIgvoQ+C4xqUwPV/WPlOCwKn7AjMuQUtBjMyyW9c5GhE9LkeXeJBpqS0x6SBI80yvG4ea+mKi5lFzDfGEE5r4m75RxYll+JZJxHNUhn/hYjfnFSmnvPOiz5rM5eN4uLwxL5MyaZDmsxATAgMBAAECgYB0Y361Dlw7pWaMuE/w3wyhcYGdICAXA+l1+EVtX8AvS+h1YEJ0d3MqlEDu2hDr5yjLalncaJVl1kJcGZ3Os1JgEHsk42+oN/N7imQTBd8k1iYyNcv1SH24WwvyEN9T8zJObdiUu+orVsyE1sdO4yXi+aIlziqFJ+DH7aQGs4ykqQJBAOeRPv72+/yD7Bz4e/yLop5I2RPipzFhIp0oSKfRlKQCMvX4IgIgJ9C0nIQ79AoUEx/ug8SrXr9UOMzUOfZV+dUCQQCwsrunyFvLBzV0EGi+r42MrHXxdt63M07pXtVbJZzYJOnZENK24w32nE+7aLiwYSmZbGz3sFSWD482GrGq3K5HAkAj9ZEjxLTSvKWwxgFy8TgaflN/XAX8jAn0/6lwrgH4CgNh4NtfGyEzrqhTfH/kBMQHhGFf7AC1k12SqS4rC6TVAkAhxlhGTu701PDruYM8B7Rn0kNNH2qc3ArWYtEndf4P9qZYXnXYjXgKzoATE4ZR+JCKCgaeJa9Va631Ko8RWNNbAkEApNFB/aB/U7/j+5G74b/ro8xnOfOiRo1KvsDMJ/lsXmUI3fS/f32CdV3Cw1pBJE5D/0dSV3PBM19vOqB4Wd2omg==" ;
//			String checkString = AlipaySignature.rsaSign(signContent,prikey,"utf-8") ;
//			System.out.println("java签名："+checkString);
//			boolean result = AlipaySignature.rsaCheckContent(signContent.toString(),sign,publickey,"utf-8") ;
//			System.out.println(result);
//
//		}catch (Exception e){
//			e.printStackTrace();
//		}
//	}



}

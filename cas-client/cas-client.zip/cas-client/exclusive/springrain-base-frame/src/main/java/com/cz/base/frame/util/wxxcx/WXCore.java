package com.cz.base.frame.util.wxxcx;



import org.apache.commons.codec.binary.Base64;
import net.sf.json.JSONObject;

/**
 * 封装对外访问方法
 * @author liuyazhuang
 *
 */
public class WXCore {

    private static final String WATERMARK = "watermark";
    private static final String APPID = "appid";
    /**
     * 解密数据
     * @return
     * @throws Exception
     */
    public static String decrypt(String appId, String encryptedData, String sessionKey, String iv){
        String result = "";
        try {
            AES aes = new AES();
            byte[] resultByte = aes.decrypt(Base64.decodeBase64(encryptedData), Base64.decodeBase64(sessionKey), Base64.decodeBase64(iv));
            if(null != resultByte && resultByte.length > 0){
                result = new String(WxPKCS7Encoder.decode(resultByte));
                JSONObject jsonObject = JSONObject.fromObject(result);
                String decryptAppid = jsonObject.getJSONObject(WATERMARK).getString(APPID);
                if(!appId.equals(decryptAppid)){
                    result = "";
                }
            }
        } catch (Exception e) {
            result = "";
            e.printStackTrace();
        }
        return result;
    }


    public static void main(String[] args) throws Exception{
        String appId = "wx2c3cde186bdd2312";
//        String encryptedData = "Sku5L4jC2hscWGuEivq15YrAEZ3pPQoHtVWS4/zlowr5+J3MX8HdH5MIcp3tP2B/vj3ohXkblMBmnPoEQMR21FLE7e53vZB6M643yUjl8QljCihRIr6Kzh2f2CXMgCzm4A2/rv6eGea6swfN4m28bWAmOCngjJi+Z4Lep+edBZwVkOc5BxP3PN38D/7++rAO0+TpL3EWC58JicBg85nPRoGGAJJ0HXjuRQTdCFraduTJCBcMZRoWk6LlKyX+pfI0Yi60BgiImhcOj+T4Kz6kAoRcKWIAZUNXxmjxa39WevSPn9GHOXVIBw0AIH4Rerfe8vkbPxfSBPke4neVUIfBaBYGM7UQSSbbW+TMwITe4Wxu1UGVFC/tIwVM3I3PreQG5JWScNgjzmdPRUSTQEijK3UsEFDiawFrgca63lmnQWFeOJ1Nov/6Yh5tKwJyMFdQfppJjC104p+t3c/YUE0nt5hi3Oas4SVV6oOFBqfmZvQkJ6nppnlwt0RDWXfiNrYNrM7a3K7KuuXhgixc28QlV96Dqmikrb4pfYmTzJExSeo=";
//        String sessionKey = "fxCfaIfa0H2pm4R/xQyXfQ==";
//        String iv = "NeVlYJfRzVg5a8dByBeY3Q==";
        String encryptedData = "Oz6ibMRIcq75Gyx1jbo+iup3uqsexQpKwFAm7TIgMa7qTiBRE8auKx9yKweki49hHQshkhCjwu0a2ryaUwWNa9ydlXZYZ54y9fjReLtiXaQaqyTQ+K55BaNgOks/ZCRVJcSM+wyxx5KTLKrKyHFwfBYT9XL/t/uMaCn86VhpclcDtl/5gMAYPK49VYCqO5gpoWKMFjrEcX/BHTmRT/bXyh+b6xnU/bvI30toHcsp0TrEj1MZaCEDJvUyZbQJdxXye9pAoXs5GXnX5DkpWMhHI9EHzx/azS9SYBa+XbWguy3s9dniWDiv5GVAMbCdm4iOa3VZKi04iQEvVeFJJ7pk7aZO8h+LJ+RY7sl53SnM+HEy0e/7xqFxQ9bVRU1a4yRnEB5OH8ct7tE0sIU2wkE4i30LMdC+Yd0u6yUJeZLhzZz8inuA3fjRG/2uxYFX22/0OlMob7TYwZvl/guojTzvOv6WX6RfcT6YS51/gcQbUyBz8P3M/u0mPoaAeIbRXVWjepCnCVJRN9CJk0PGrBGhIg==\n" +
                "";
        String sessionKey = "xE/fnqeYmDxprATlrcTZFw==";
        String iv = "RYKy9t+vsaAfh3oSAZa94Q==";
        System.out.println(decrypt(appId, encryptedData, sessionKey, iv));
    }

}

package com.cz.base.frame.cached;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.data.redis.connection.Message;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * redis超时执行的代理service
 */
@Service
public class RedisKeyExpirationDelegateService  implements ApplicationContextAware {

    @Autowired
    private RedisTemplate<String, Object> redisTemplate;

    private ApplicationContext applicationContext;

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

    public void onMessage(Message message, byte[] pattern) throws Exception{
        Map<String, IRedisExpriationCallbackService> callbacks  =applicationContext.getBeansOfType(IRedisExpriationCallbackService.class);
        String key = redisTemplate.getKeySerializer().deserialize(message.getBody()).toString();
        for (IRedisExpriationCallbackService callback : callbacks.values()) {
            callback.onMessage(key ,message, pattern);
        }
    }
}

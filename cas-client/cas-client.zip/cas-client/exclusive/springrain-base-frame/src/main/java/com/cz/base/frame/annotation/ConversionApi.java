package com.cz.base.frame.annotation;

import java.lang.annotation.*;

/**
 *  标记可以用于api接口返回数据加密，引用此注解的方法都会配合SecurityAspect进行加密
 * @author Michael
 * @version  2017-03-08 11:08:15
 * @see ConversionApi
 */
@Target({ElementType.PARAMETER, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface ConversionApi {
//	String description()  default "";
	String value() default "" ;
}

package com.cz.base.frame.cached;

import org.springframework.data.redis.connection.Message;

/**
 * redis超时回调处理接口，凡是实现了这个接口的类，会在超时后被调用
 */
public interface IRedisExpriationCallbackService {
    void onMessage(String key, Message message, byte[] pattern) throws Exception;
}

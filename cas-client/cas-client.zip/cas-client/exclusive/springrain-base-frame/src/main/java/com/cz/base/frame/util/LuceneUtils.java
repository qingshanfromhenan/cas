package com.cz.base.frame.util;

import com.cz.base.frame.util.IK.lucene.IKAnalyzer;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.map.HashedMap;
import org.apache.commons.lang3.StringUtils;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.Field.Store;
import org.apache.lucene.document.StringField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.*;
import org.apache.lucene.queryparser.classic.MultiFieldQueryParser;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.BooleanClause.Occur;
import org.apache.lucene.search.*;
import org.apache.lucene.search.BooleanQuery.Builder;
import org.apache.lucene.search.highlight.*;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;


/**
 * lucene 工具类
 * 
 * @author caomei
 *
 */
public class LuceneUtils {

    private static final Logger logger = LoggerFactory.getLogger(LuceneUtils.class);

    private LuceneUtils() {
        throw new IllegalAccessError("工具类不能实例化");
    }

    // 分词器,使用IK的精确匹配
    private static Analyzer analyzer = new IKAnalyzer();

	// 分词器
//	private static Analyzer analyzer = new SmartChineseAnalyzer();

	
	/**
	 * 根据实体类查询结果
	 * 
	 * @param clazz
	 * @param page
	 * @param searchkeyword
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static List searchDocument(String rootdir,Class clazz, Page page,
			String searchkeyword) throws Exception {
		List<String> luceneFields = ClassUtils.getLuceneFields(clazz);
		if (CollectionUtils.isEmpty(luceneFields)) {
			return null;
		}
		String[] fields = (String[]) luceneFields
				.toArray(new String[luceneFields.size()]);
		return searchDocument( rootdir,clazz, page, fields, searchkeyword);
	}

	
	/**
	 * 根据某个字段类查询结果
	 * 
	 * @param clazz
	 * @param page
	 * @param searchkeyword
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static List searchDocument(String rootdir,Class clazz, Page page, String field,
			String searchkeyword) throws Exception {
		if (StringUtils.isBlank(field)) {
			return null;
		}
		String[] fields = new String[] { field };
		return searchDocument( rootdir,clazz, page, fields, searchkeyword);
	}

	public static <T> List<T> searchDocument(String rootdir,Class<T> clazz, Page page,
			String[] fields, List<String> searchkeyword) throws Exception {
		if (fields == null || fields.length < 1) {
			return null;
		}
		// 解析分词
		// 获取第一个组合数量

		// 获取索引目录文件
		Directory directory = getDirectory(rootdir,clazz);
		if (directory == null) {
			return null;
		}
		// 获取读取的索引
		IndexReader indexReader = DirectoryReader.open(directory);
		// 获取索引的查询器
		IndexSearcher indexSearcher = new IndexSearcher(indexReader);

		// 查询指定字段的转换器
		QueryParser parser = new MultiFieldQueryParser(fields, analyzer);
		Builder addBuilder = new Builder();
		// 构建多条and查询
		for (String _sk : searchkeyword) {
			Query query = parser.parse(_sk);
			addBuilder.add(query, Occur.MUST);
		}

		// 需要查询的关键字

		TopDocs topDocs = null;
		BooleanQuery andQuery=addBuilder.build();
		int totalCount = indexSearcher.count(andQuery);
		if (totalCount == 0) {
			return null;
		}
		if (page == null) {
			topDocs = indexSearcher.search(andQuery, totalCount);
		} else {
			// 查询出的结果文档
			int _size = 20;
			if (page != null && page.getPageSize() > 0) {
				_size = page.getPageSize();
			}

			// 总条数
			page.setTotalCount(totalCount);

			int _max = page.getPageIndex() * (page.getPageIndex() - 1);
			if (_max - totalCount >= 0) {
				return null;
			}
			// 先获取上一页的最后一个元素
			ScoreDoc lastscoreDoc = getLastScoreDoc(page.getPageIndex(), _size,
					andQuery, indexSearcher);
			topDocs = indexSearcher.searchAfter(lastscoreDoc, andQuery, _size);
		}

		// 查询出的结果文档
		ScoreDoc[] hits = topDocs.scoreDocs;

		if (hits == null || hits.length < 1) {
			return null;
		}

		List<T> list = new ArrayList<T>(hits.length);
		for (int i = 0; i < hits.length; i++) {
			Document hitDoc = indexSearcher.doc(hits[i].doc);
			T t = clazz.newInstance();
			for (String fieldName : ClassUtils.getLuceneFields(clazz)) {
				String fieldValue = hitDoc.get(fieldName);
				ClassUtils.setPropertieValue(fieldName, t, fieldValue);
			}
			list.add(t);
		}
		indexReader.close();
		directory.close();

		return list;
	}

	/**
	 * 
	 * @param clazz
	 * @param page
	 * @param fields
	 * @param searchkeyword
	 * @return
	 * @throws Exception
	 */
	public static <T> List<T> searchDocument(String rootdir,Class<T> clazz, Page page,
			String[] fields, String searchkeyword) throws Exception {

		if (fields == null || fields.length < 1) {
			return null;
		}

		// 获取索引目录文件
		Directory directory = getDirectory( rootdir,clazz);
		if (directory == null) {
			return null;
		}

		// 获取读取的索引
		IndexReader indexReader = DirectoryReader.open(directory);
		// 获取索引的查询器
		IndexSearcher indexSearcher = new IndexSearcher(indexReader);

		// 查询指定字段的转换器
		QueryParser parser = new MultiFieldQueryParser(fields, analyzer);
		// 需要查询的关键字
		Query query = parser.parse(searchkeyword);

		//算分
		QueryScorer scorer=new QueryScorer(query);

		//显示得分高的片段
		Fragmenter fragmenter=new SimpleSpanFragmenter(scorer);
		//设置标签内部关键字的颜色
		//第一个参数：标签的前半部分；第二个参数：标签的后半部分。
		SimpleHTMLFormatter simpleHTMLFormatter=new SimpleHTMLFormatter("<font color='red'>","</font>");

		//第一个参数是对查到的结果进行实例化；第二个是片段得分（显示得分高的片段，即摘要）
		Highlighter highlighter=new Highlighter(simpleHTMLFormatter, scorer);


		TopDocs topDocs = null;
		int totalCount = indexSearcher.count(query);
		if (totalCount == 0) {
			return null;
		}
		if (page == null) {
			topDocs = indexSearcher.search(query, totalCount);
		} else {
			// 查询出的结果文档
			int _size = 20;
			if (page != null && page.getPageSize() > 0) {
				_size = page.getPageSize();
			}
			// 总条数
			page.setTotalCount(totalCount);
			int _max = page.getPageIndex() * (page.getPageIndex() - 1);
			if (_max - totalCount >= 0) {
				return null;
			}

			// 先获取上一页的最后一个元素
			ScoreDoc lastscoreDoc = getLastScoreDoc(page.getPageIndex(), _size,query, indexSearcher);
			topDocs = indexSearcher.searchAfter(lastscoreDoc, query, _size);
		}
		// 通过最后一个元素搜索下页的pageSize个元素

		// 查询出的结果文档
		ScoreDoc[] hits = topDocs.scoreDocs;

		if (hits == null || hits.length < 1) {
			return null;
		}

		List<T> list = new ArrayList<T>(hits.length);
		for (int i = 0; i < hits.length; i++) {
			Document hitDoc = indexSearcher.doc(hits[i].doc);
			T t = document2Bean(hitDoc,clazz,highlighter) ;
			list.add(t);
		}
		indexReader.close();
		directory.close();

		return list;
	}

	/**
	 * 根据实体类保存到索引,使用 LuceneSearch和LuceneField
	 * 
	 * @param entity
	 * @return
	 * @throws Exception
	 */
	public  static String saveDocument(String rootdir,Object entity)
			throws Exception {
		// 获取索引的字段,为null则不进行保存
		List<String> luceneFields = ClassUtils.getLuceneFields(entity
				.getClass());
		if (CollectionUtils.isEmpty(luceneFields)) {
			return "error";
		}

		// 索引写入配置
		IndexWriterConfig indexWriterConfig = new IndexWriterConfig(analyzer);
		// 获取索引目录文件
		Directory directory = getDirectory( rootdir,entity.getClass());
		if (directory == null) {
			return null;
		}
		IndexWriter indexWriter = new IndexWriter(directory, indexWriterConfig);
		Document doc = new Document();
		for (String fieldName : luceneFields) {
			Object _obj = ClassUtils.getPropertieValue(fieldName, entity);
			if (_obj == null) {
				_obj = "";
			}
			String _value = _obj.toString();
			Field _field = null;
			
			if (ClassUtils.getEntityInfoByEntity(entity).getPkName()
					.equals(fieldName)) {
				_field = new StringField(ClassUtils.getEntityInfoByEntity(
						entity).getPkName(), _value, Store.YES);
			} else {
				_field = new Field(fieldName, _value, TextField.TYPE_STORED);
			}

			doc.add(_field);
		}
		indexWriter.addDocument(doc);
		indexWriter.commit();
		indexWriter.close();
		directory.close();
		return null;
	}

	/**
	 * 根据实体类批量保存到索引,使用 LuceneSearch和LuceneField
	 * 
	 * @param entity
	 * @return
	 * @throws Exception
	 */
	public static <T> String saveListDocument(String rootdir,List<T> list) throws Exception {
		if (CollectionUtils.isEmpty(list)) {
			return "error";
		}
		for (T t : list) {
			saveDocument( rootdir,t);
		}

		return null;
	}

	/**
	 * 删除文档
	 * 
	 * @param entity
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	public  static String deleteDocument(String rootdir,Object id, Class clazz)
			throws Exception {
		List<String> luceneFields = ClassUtils.getLuceneFields(clazz);
		if (CollectionUtils.isEmpty(luceneFields)) {
			return "error";
		}

		String pkName = ClassUtils.getEntityInfoByClass(clazz).getPkName();
		// 索引写入配置
		IndexWriterConfig indexWriterConfig = new IndexWriterConfig(analyzer);
		// 获取索引目录文件
		Directory directory = getDirectory( rootdir,clazz);
		if (directory == null) {
			return null;
		}
		IndexWriter indexWriter = new IndexWriter(directory, indexWriterConfig);
		
		// 需要查询的关键字
		Term term = new Term(pkName,id.toString());
		TermQuery luceneQuery = new TermQuery(term);
		indexWriter.deleteDocuments(luceneQuery);
		indexWriter.commit();
		indexWriter.close(); // 记得关闭,否则删除不会被同步到索引文件中
		directory.close(); // 关闭目录
		
		return null;
	}

	/**
	 * 批量删除文档
	 * 
	 * @param entity
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	public static String deleteListDocument(String rootdir,List<String> ids, Class clazz)
			throws Exception {
		List<String> luceneFields = ClassUtils.getLuceneFields(clazz);
		if (CollectionUtils.isEmpty(luceneFields)) {
			return "error";
		}
		if (CollectionUtils.isEmpty(ids)) {
			return "error";
		}
		String pkName = ClassUtils.getEntityInfoByClass(clazz).getPkName();
		// 索引写入配置
		IndexWriterConfig indexWriterConfig = new IndexWriterConfig(analyzer);
		// 获取索引目录文件
		Directory directory = getDirectory( rootdir,clazz);
		if (directory == null) {
			return null;
		}
		IndexWriter indexWriter = new IndexWriter(directory, indexWriterConfig);
		for (String t : ids) {
			// 需要查询的关键字
			Term term = new Term(pkName,t);
			TermQuery luceneQuery = new TermQuery(term);
			indexWriter.deleteDocuments(luceneQuery);
		}
		indexWriter.commit();
		indexWriter.close(); // 记得关闭,否则删除不会被同步到索引文件中
		directory.close(); // 关闭目录
		return null;
	}

	/**
	 * 删除所有索引
	 * @param ids
	 * @param clazz
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	public static String deleteDocumentAll(String rootdir,Class clazz)
			throws Exception {
		// 索引写入配置
		IndexWriterConfig indexWriterConfig = new IndexWriterConfig(analyzer);
		// 获取索引目录文件
		Directory directory = getDirectory( rootdir,clazz);
		if (directory == null) {
			return null;
		}
		IndexWriter indexWriter = new IndexWriter(directory, indexWriterConfig);
		indexWriter.deleteAll();
		indexWriter.commit();
		indexWriter.close(); // 记得关闭,否则删除不会被同步到索引文件中
		directory.close(); // 关闭目录
		return null;
	}


	/**
	 * 修改文档
	 * 
	 * @param entity
	 * @return
	 * @throws Exception
	 */
	public static String updateDocument(String rootdir,Object entity) throws Exception {
		
		String pkValue = ClassUtils.getPKValue(entity).toString();
		deleteDocument( rootdir,pkValue, entity.getClass());
		saveDocument( rootdir,entity);
		return null;
	}

	/**
	 * 批量修改文档
	 * 
	 * @param entity
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	public static <T> String updateListDocument(String rootdir,List<T> list) throws Exception {

		if (CollectionUtils.isEmpty(list)) {
			return null;
		}
		List<String> ids = new ArrayList<String>();
		Class clazz = list.get(0).getClass();
		for (T t : list) {
			String id = ClassUtils.getPKValue(t).toString();
			ids.add(id);
		}
		deleteListDocument( rootdir,ids, clazz);
		saveListDocument( rootdir,list);
		return null;
	}

	/**
	 * 获取索引的目录
	 * 
	 * @param clazz
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public static File getIndexDirFile(String rootdir,Class clazz) {
		if (clazz == null) {
			return null;
		}
		File file = new File(rootdir + "/" + clazz.getName());
		if (!file.exists()) {
			file.mkdirs();
		}
		return file;

	}

	/**
	 * 获取实体类的索引文档
	 * 
	 * @param clazz
	 * @return
	 * @throws IOException
	 */
	@SuppressWarnings("rawtypes")
	public static Directory getDirectory(String rootdir,Class clazz) throws IOException {
		File indexDirFile = getIndexDirFile(rootdir,clazz);
		if (indexDirFile == null) {
			return null;
		}
		Path indexDirPath = indexDirFile.toPath();
		// 索引不可读
		if (!Files.isReadable(indexDirPath)) {
			return null;
		}
		// 获取索引目录文件
		Directory directory = FSDirectory.open(indexDirPath);
		return directory;

	}

	/**
	 * 根据页码和分页大小获取上一次的最后一个ScoreDoc
	 */
	private static ScoreDoc getLastScoreDoc(int pageIndex, int pageSize,
			Query query, IndexSearcher searcher) throws IOException {
		if (pageIndex <= 1)
			return null;// 如果是第一页就返回空
		int num = pageSize * (pageIndex - 1);// 获取上一页的数量
		TopDocs tds = searcher.search(query, num);
		return tds.scoreDocs[num - 1];
	}


	/**
	 * 索引文档转化为bean
	 *
	 * @param document
	 * @param t
	 * @return
	 * @throws Exception
	 */
	private static <T> T document2Bean(Document document, Class<T> clazz,Highlighter highlighter) throws Exception {

		if (document == null || clazz == null) {
			return null;
		}

		List<String> luceneFields = ClassUtils.getLuceneFields(clazz);

		if (CollectionUtils.isEmpty(luceneFields)) {
			return null;
		}

		Map<String, Object> map = new HashedMap<>();

		for (String finfo : luceneFields) {
			String fieldName = finfo;
			String fieldValue = document.get(fieldName);

			if (StringUtils.isBlank(fieldValue)) {
				continue;
			}

			java.lang.reflect.Field field = clazz.getDeclaredField(fieldName) ;
			String fieldType = field.getGenericType().getTypeName() ;

			String highlighterValue = null ;
			if (highlighter != null) {
				//把全部得分高的摘要给显示出来
				//第一个参数是对哪个参数进行设置；第二个是以流的方式读入
				TokenStream tokenStream=analyzer.tokenStream(fieldName, new StringReader(fieldValue));

				//获取最高的片段
				highlighterValue = highlighter.getBestFragment(tokenStream, fieldValue) ;
				if (StringUtils.isNotBlank(highlighterValue) && "java.lang.String".equals(fieldType)) {
					fieldValue = highlighterValue ;
				}
			}

			if ("java.lang.Integer".equals(fieldType)) {// 数字

				// ClassUtils.setPropertieValue(fieldName, t, Integer.valueOf(fieldValue));
				map.put(fieldName, Integer.valueOf(fieldValue));

			} else if ("java.math.BigInteger".equals(fieldType)) {// 数字
				// ClassUtils.setPropertieValue(fieldName, t, new BigInteger(fieldValue));
				map.put(fieldName, new BigInteger(fieldValue));

			} else if ("java.lang.Long".equals(fieldType)) {// 数字
				// ClassUtils.setPropertieValue(fieldName, t, Long.valueOf(fieldValue));
				map.put(fieldName, Long.valueOf(fieldValue));

			} else if ("java.lang.Float".equals(fieldType)) {// 数字
				// ClassUtils.setPropertieValue(fieldName, t, Float.valueOf(fieldValue));
				map.put(fieldName, Float.valueOf(fieldValue));

			} else if ("java.lang.Double".equals(fieldType) ) {// 数字
				// ClassUtils.setPropertieValue(fieldName, t, Double.valueOf(fieldValue));
				map.put(fieldName, Double.valueOf(fieldValue));
			} else if ("java.math.BigDecimal".equals(fieldType)) {// BigDecimal
				// ClassUtils.setPropertieValue(fieldName, t, new BigDecimal(fieldValue));
				map.put(fieldName, new BigDecimal(fieldValue));
			} else if ("java.util.Date".equals(fieldType)) {// 日期
				// ClassUtils.setPropertieValue(fieldName, t, new
				// Date(Long.valueOf(fieldValue)));
				map.put(fieldName, Long.valueOf(fieldValue));
			} else {
				// ClassUtils.setPropertieValue(fieldName, t, fieldValue);
				map.put(fieldName, fieldValue);
			}
		}

		T t = JsonUtils.readValue(JsonUtils.writeValueAsString(map), clazz);

		return t;

	}
}
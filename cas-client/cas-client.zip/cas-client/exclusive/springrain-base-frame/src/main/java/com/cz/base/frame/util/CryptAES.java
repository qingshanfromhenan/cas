package com.cz.base.frame.util;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.RandomStringUtils;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.security.Key;
import java.util.UUID;

/**
 * php与java通用AES加密解密算法
 * AES指高级加密标准（Advanced Encryption Standard）,是当前最流行的一种密码算法，在web应用开发，特别是对外提供接口时经常会用到，
 * 下面是整理的一套php与java通用的AES加密解密算法。
 * @author Administrator
 *
 */
public class CryptAES {
	
	private static final String AESTYPE ="AES/ECB/PKCS5Padding";
	private static final  String keyStr = "UITN25LMUQC436IM";
	 
	/**
	 * 加密方法
	 * @param plainText
	 * @return
	 */
    public static String AES_Encrypt(String plainText) {
        byte[] encrypt = null;
        try{
            Key key = generateKey(keyStr);
            Cipher cipher = Cipher.getInstance(AESTYPE);
            cipher.init(Cipher.ENCRYPT_MODE, key);
            encrypt = cipher.doFinal(plainText.getBytes());    
        }catch(Exception e){
            e.printStackTrace();
        }
        return new String(Base64.encodeBase64(encrypt));
    }
 
    /**
     * 解密方法
     * @param encryptData
     * @return
     */
    public static String AES_Decrypt(String encryptData) {
        byte[] decrypt = null;
        try{
            Key key = generateKey(keyStr);
            Cipher cipher = Cipher.getInstance(AESTYPE);
            cipher.init(Cipher.DECRYPT_MODE, key);
            decrypt = cipher.doFinal(Base64.decodeBase64(encryptData));
        }catch(Exception e){
            e.printStackTrace();
        }
        return new String(decrypt).trim();
    }
 
    private static Key generateKey(String key)throws Exception{
        try{           
            SecretKeySpec keySpec = new SecretKeySpec(key.getBytes(), "AES");
            return keySpec;
        }catch(Exception e){
            e.printStackTrace();
            throw e;
        }
 
    }
    public static String[] chars = new String[] { "a", "b", "c", "d", "e", "f",
            "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s",
            "t", "u", "v", "w", "x", "y", "z", "0", "1", "2", "3", "4", "5",
            "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I",
            "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V",
            "W", "X", "Y", "Z" };


    public static String generateShortUuid() {
        StringBuffer shortBuffer = new StringBuffer();
        String uuid = UUID.randomUUID().toString().replace("-", "");
        for (int i = 0; i < 8; i++) {
            String str = uuid.substring(i * 4, i * 4 + 4);
            int x = Integer.parseInt(str, 16);
//            shortBuffer.append(chars[x % 0x3E]);
            shortBuffer.append(chars[x % 0x3E]);
        }
        return shortBuffer.toString();

    }

    public static void main(String[] args) throws Exception {
 
        String plainText = "QFATvRGsCYTmyk2Wxb90yA==";
//////
        String decString = AES_Decrypt(plainText);
//////
        System.out.println(decString);

        String s = RandomStringUtils.randomNumeric(8);
        System.out.println(s);
//
//        Integer u = 1;
//        System.out.println("1".equals(u));

//        System.out.println(generateShortUuid());

    } 

}

package com.cz.base.frame.entity;

import java.io.Serializable;

public class SysParamBean implements Serializable {

	private static final long serialVersionUID = 1L;
	public SysParamBean() {
		super();
	}

	private String apkContent ;
	private String apkImg ;
	private String apkUrl ;
	private String appIntroduce ;
	private String iOSAPPStoreCheck ;
	private String apiRSAPubKey ;
	private String apiRSASignPriKey ;

	private String kefuphone ;
	private String userRegisterProtocol ;//	用户注册协议
	private String aboutUs;//	关于我们
	private String inviteRule;//邀请好友查看规则
	private String withdrawIntroduce;//	提现说明
	private String withdrawFee;//	提现比例
	private String companyName;//	公司名称
	private String rechargeDescr;//	v币充值说明
	private String transformRule;// V钻转换规则
	private String vipServiceProtocol;//	会员服务协议
	private String autoDeductionProtocol;//	自动扣费协议
	private String autoDeductionProject;//	自动扣费项目
	private String aboutVip;// 关于会员
	private String transformFee;// V钻转换比例
	private String vTransformFee;//V币转换V钻比例
	private String withdrawServiceCharge;    //提现手续费

	private String posterCheck ;//生成海报按钮是否展示
	private String voiceCaptchaDescription ;  //语音验证码提醒描述语

	private String inviteDescr ;  // 邀请人员描述语
	private String productClickDescr ;  // 课程点击量描述语
	private String diamondEarningsDescr ;  // 钻石收益描述语
	private String bigVipDescr ;  // 大v会员描述语
	private String domain;//云直播推流域名
	private String pushKey;//推流防盗链Key

	private String onlineService ;	// 在线客服
	private String registerURL; // H5注册url
	private String productContent;	//	获取产品图文

	public String getProductContent() {
		return productContent;
	}

	public void setProductContent(String productContent) {
		this.productContent = productContent;
	}

	public String getRegisterURL() {
		return registerURL;
	}

	public void setRegisterURL(String registerURL) {
		this.registerURL = registerURL;
	}

	public String getOnlineService() {
		return onlineService;
	}

	public void setOnlineService(String onlineService) {
		this.onlineService = onlineService;
	}

	public String getInviteDescr() {
		return inviteDescr;
	}

	public void setInviteDescr(String inviteDescr) {
		this.inviteDescr = inviteDescr;
	}

	public String getProductClickDescr() {
		return productClickDescr;
	}

	public void setProductClickDescr(String productClickDescr) {
		this.productClickDescr = productClickDescr;
	}

	public String getDiamondEarningsDescr() {
		return diamondEarningsDescr;
	}

	public void setDiamondEarningsDescr(String diamondEarningsDescr) {
		this.diamondEarningsDescr = diamondEarningsDescr;
	}

	public String getBigVipDescr() {
		return bigVipDescr;
	}

	public void setBigVipDescr(String bigVipDescr) {
		this.bigVipDescr = bigVipDescr;
	}

	public String getWithdrawServiceCharge() {
		return withdrawServiceCharge;
	}

	public void setWithdrawServiceCharge(String withdrawServiceCharge) {
		this.withdrawServiceCharge = withdrawServiceCharge;
	}

	public String getVoiceCaptchaDescription() {
		return voiceCaptchaDescription;
	}

	public void setVoiceCaptchaDescription(String voiceCaptchaDescription) {
		this.voiceCaptchaDescription = voiceCaptchaDescription;
	}

	public String getPosterCheck() {
		return posterCheck;
	}

	public void setPosterCheck(String posterCheck) {
		this.posterCheck = posterCheck;
	}

	public String getvTransformFee() {
		return vTransformFee;
	}

	public void setvTransformFee(String vTransformFee) {
		this.vTransformFee = vTransformFee;
	}

	public String getTransformFee() {
		return transformFee;
	}

	public void setTransformFee(String transformFee) {
		this.transformFee = transformFee;
	}

	public String getApkContent() {
		return apkContent;
	}

	public void setApkContent(String apkContent) {
		this.apkContent = apkContent;
	}

	public String getApkImg() {
		return apkImg;
	}

	public void setApkImg(String apkImg) {
		this.apkImg = apkImg;
	}

	public String getApkUrl() {
		return apkUrl;
	}

	public void setApkUrl(String apkUrl) {
		this.apkUrl = apkUrl;
	}

	public String getAppIntroduce() {
		return appIntroduce;
	}

	public void setAppIntroduce(String appIntroduce) {
		this.appIntroduce = appIntroduce;
	}

	public String getiOSAPPStoreCheck() {
		return iOSAPPStoreCheck;
	}

	public void setiOSAPPStoreCheck(String iOSAPPStoreCheck) {
		this.iOSAPPStoreCheck = iOSAPPStoreCheck;
	}

	public String getApiRSAPubKey() {
		return apiRSAPubKey;
	}

	public void setApiRSAPubKey(String apiRSAPubKey) {
		this.apiRSAPubKey = apiRSAPubKey;
	}

	public String getApiRSASignPriKey() {
		return apiRSASignPriKey;
	}

	public void setApiRSASignPriKey(String apiRSASignPriKey) {
		this.apiRSASignPriKey = apiRSASignPriKey;
	}

	public String getKefuphone() {
		return kefuphone;
	}

	public void setKefuphone(String kefuphone) {
		this.kefuphone = kefuphone;
	}

	public String getUserRegisterProtocol() {
		return userRegisterProtocol;
	}

	public void setUserRegisterProtocol(String userRegisterProtocol) {
		this.userRegisterProtocol = userRegisterProtocol;
	}

	public String getAboutUs() {
		return aboutUs;
	}

	public void setAboutUs(String aboutUs) {
		this.aboutUs = aboutUs;
	}

	public String getInviteRule() {
		return inviteRule;
	}

	public void setInviteRule(String inviteRule) {
		this.inviteRule = inviteRule;
	}

	public String getWithdrawIntroduce() {
		return withdrawIntroduce;
	}

	public void setWithdrawIntroduce(String withdrawIntroduce) {
		this.withdrawIntroduce = withdrawIntroduce;
	}

	public String getWithdrawFee() {
		return withdrawFee;
	}

	public void setWithdrawFee(String withdrawFee) {
		this.withdrawFee = withdrawFee;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getRechargeDescr() {
		return rechargeDescr;
	}

	public void setRechargeDescr(String rechargeDescr) {
		this.rechargeDescr = rechargeDescr;
	}

	public String getTransformRule() {
		return transformRule;
	}

	public void setTransformRule(String transformRule) {
		this.transformRule = transformRule;
	}

	public String getVipServiceProtocol() {
		return vipServiceProtocol;
	}

	public void setVipServiceProtocol(String vipServiceProtocol) {
		this.vipServiceProtocol = vipServiceProtocol;
	}

	public String getAutoDeductionProtocol() {
		return autoDeductionProtocol;
	}

	public void setAutoDeductionProtocol(String autoDeductionProtocol) {
		this.autoDeductionProtocol = autoDeductionProtocol;
	}

	public String getAutoDeductionProject() {
		return autoDeductionProject;
	}

	public void setAutoDeductionProject(String autoDeductionProject) {
		this.autoDeductionProject = autoDeductionProject;
	}

	public String getAboutVip() {
		return aboutVip;
	}

	public void setAboutVip(String aboutVip) {
		this.aboutVip = aboutVip;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public String getPushKey() {
		return pushKey;
	}

	public void setPushKey(String pushKey) {
		this.pushKey = pushKey;
	}
}

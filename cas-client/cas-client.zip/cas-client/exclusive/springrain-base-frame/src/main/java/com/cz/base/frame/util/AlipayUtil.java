package com.cz.base.frame.util;

import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.domain.AlipayTradeAppPayModel;
import com.alipay.api.domain.AlipayTradeWapPayModel;
import com.alipay.api.request.*;
import com.alipay.api.response.*;
import com.cz.base.frame.entity.ConfigBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 *支付宝工具类
 */
@Component
public class AlipayUtil {
	@Autowired
	CacheManager cacheManager ;

	private static CacheManager staticCacheManager ;

	@PostConstruct
	public void  init(){
		staticCacheManager = this.cacheManager ;
	}


	public static String signRSA2Data(String outtradeno,String totalAmount ,String subject,String body) throws Exception{
		Cache cache = staticCacheManager.getCache(GlobalStatic.cacheKey) ;
		ConfigBean configBean = cache.get(GlobalStatic.configCache, ConfigBean.class);
		//实例化客户端
		AlipayClient alipayClient = new DefaultAlipayClient("https://openapi.alipay.com/gateway.do", configBean.getAlipayAppId(), configBean.getAlipayPrivateKey(), "json", "utf-8", configBean.getAlipayPublicKey(), "RSA2");
		//实例化具体API对应的request类,类名称和接口名称对应,当前调用接口名称：alipay.trade.app.pay
		AlipayTradeAppPayRequest request = new AlipayTradeAppPayRequest();
		//SDK已经封装掉了公共参数，这里只需要传入业务参数。以下方法为sdk的model入参方式(model和biz_content同时存在的情况下取biz_content)。
		AlipayTradeAppPayModel model = new AlipayTradeAppPayModel();
		model.setBody(body);
		model.setSubject(subject);
		model.setOutTradeNo(outtradeno);
		model.setTimeoutExpress("30m");
		model.setTotalAmount(totalAmount);
		model.setProductCode("QUICK_MSECURITY_PAY");
		model.setSellerId(configBean.getAlipayPartner());
		request.setBizModel(model);
		request.setNotifyUrl(configBean.getAlipayCallBackUrl());
		//这里和普通的接口调用不同，使用的是sdkExecute
		AlipayTradeAppPayResponse response = alipayClient.sdkExecute(request);
		return response.getBody() ;
	}
	/**
	 * 对支付宝批量退款退款所需要的请求参数进行封装
	 * @param return_datail
	 * @param id
	 * @return
	 * @throws Exception
	 */
	public static AlipayTradeRefundResponse zfbreturn(String tradeNo, String amount) throws Exception{
		Cache cache = staticCacheManager.getCache(GlobalStatic.cacheKey) ;
		ConfigBean configBean = cache.get(GlobalStatic.configCache, ConfigBean.class);
		AlipayClient alipayClient = new DefaultAlipayClient(configBean.getAlipayRefundUrl(),configBean.getAlipayAppId(),configBean.getAlipayPrivateKey(),"json","utf-8",configBean.getAlipayPublicKey(),"RSA");
		AlipayTradeRefundRequest request = new AlipayTradeRefundRequest();
		request.setBizContent("{" +
				"\"trade_no\":\""+tradeNo+"\"," +
				"\"refund_amount\":"+amount+"," +
				"\"refund_reason\":\"正常退款\"" +
				"  }");
		AlipayTradeRefundResponse response = alipayClient.execute(request);
		return response;
	}

	/**
	 * 对支付宝回调参数进行解析
	 * @param requestParams
	 * @return
	 * @throws Exception
	 */
	public static Map<String, String> getNotifyParam(Map requestParams ) throws Exception{
		Map<String,String> params = new HashMap<String,String>();
		for (Iterator iter = requestParams.keySet().iterator(); iter.hasNext();) {
			String name = (String) iter.next();
			String[] values = (String[]) requestParams.get(name);
			String valueStr = "";
			for (int i = 0; i < values.length; i++) {
				valueStr = (i == values.length - 1) ? valueStr + values[i]
						: valueStr + values[i] + ",";
			}
			//乱码解决，这段代码在出现乱码时使用。如果mysign和sign不相等也可以使用这段代码转化
			//valueStr = new String(valueStr.getBytes("ISO-8859-1"), "gbk");
			if(!"id".equals(name)){
				params.put(name, valueStr);
			}
		}
		return params;
	}


	/**
	 * 支付宝获取用户信息
	 * @param code
	 * @return
	 * @throws Exception
	 */
	public static AlipayUserInfoShareResponse getAlipayUser(String code) throws Exception{
		Cache cache = staticCacheManager.getCache(GlobalStatic.cacheKey) ;
		ConfigBean configBean = cache.get(GlobalStatic.configCache, ConfigBean.class);
		AlipayClient alipayClient = new DefaultAlipayClient(configBean.getAlipayRefundUrl(),configBean.getAlipayAppId(),configBean.getAlipayPrivateKey(),"json","utf-8",configBean.getAlipayPublicKey(),"RSA2");
		AlipaySystemOauthTokenRequest request = new AlipaySystemOauthTokenRequest();
		request.setCode(code);
		request.setGrantType("authorization_code");
		AlipayUserInfoShareResponse response = null;
		try {
			AlipaySystemOauthTokenResponse oauthTokenResponse = alipayClient.execute(request);
			System.out.println(oauthTokenResponse.getAccessToken());
			AlipayUserInfoShareRequest requestAccToken = new AlipayUserInfoShareRequest();
			response = alipayClient.execute(requestAccToken,oauthTokenResponse.getAccessToken());
			System.out.println(response+"支付宝信息++++++++++++++++++++++++++++++++++++");
		} catch (AlipayApiException e) {
			//处理异常
			e.printStackTrace();
		}
		return response;
	}
	
	public static String zfbPay(String orderNumber,String amount) throws Exception{
		try {
			Cache cache = staticCacheManager.getCache(GlobalStatic.cacheKey) ;
			ConfigBean configBean = cache.get(GlobalStatic.configCache, ConfigBean.class);
			AlipayClient alipayClient = new DefaultAlipayClient(configBean.getAlipayRefundUrl(),configBean.getAlipayAppId(),configBean.getAlipayPrivateKey(),"json","utf8",configBean.getAlipayPublicKey(),"RSA2");
			AlipayTradeWapPayRequest alipay_request=new AlipayTradeWapPayRequest();
			// 封装请求支付信息
			AlipayTradeWapPayModel model=new AlipayTradeWapPayModel();
			model.setOutTradeNo(orderNumber);
			model.setSubject("美好生活家园在线支付");
			model.setTotalAmount(amount);
			model.setBody("美好生活家园在线支付");
			model.setTimeoutExpress("2m");
			model.setProductCode("QUICK_WAP_PAY");
			alipay_request.setBizModel(model);
			// 设置异步通知地址
			alipay_request.setNotifyUrl(configBean.getAlipayCallBackUrl());
			// 设置同步地址
//			alipay_request.setReturnUrl("http://114.55.4.234/alipay.trade.wap.pay-JAVA-UTF-8/return_url.jsp");
			// 调用SDK生成表单
			String form = alipayClient.pageExecute(alipay_request).getBody();
			StringBuffer returnHtml = new StringBuffer("");
			returnHtml.append("<html>");
			String head = "<head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" pageEncoding=\"utf-8\" />";
			returnHtml.append(head);
			returnHtml.append("<title>loading</title>");
			returnHtml.append("<style type=\"text/css\">");
			returnHtml.append("body{margin:200px auto;font-family: \"宋体\", Arial;font-size: 12px;color: #369;text-align: center;}");
			returnHtml.append("#1{height:auto; width:78px; margin:0 auto;}");
			returnHtml.append("#2{height:auto; width:153px; margin:0 auto;}");
			returnHtml.append("vertical-align: bottom;}");
			returnHtml.append("</style>");
			returnHtml.append("</head>");
			returnHtml.append("<body>");
			returnHtml.append("<div id=\"3\">跳转中...</div>");
			returnHtml.append(form);
			returnHtml.append("</body>");
			returnHtml.append("</html>");
			return returnHtml.toString();
		}catch (Exception e){
			e.printStackTrace();
		}
		return null;
	}
	
	
	/**
	 * 支付宝条形码支付
	 * @param orderNumber
	 * @param amount
	 * @param authCode
	 * @return
	 * @throws Exception
	 */
	public static AlipayTradePayResponse zfbBarCodePay(String orderNumber, String amount, String authCode) throws Exception{
		Cache cache = staticCacheManager.getCache(GlobalStatic.cacheKey) ;
		ConfigBean configBean = cache.get(GlobalStatic.configCache, ConfigBean.class);
		AlipayClient alipayClient = new DefaultAlipayClient(configBean.getAlipayRefundUrl(),configBean.getAlipayAppId(),configBean.getAlipayPrivateKey(),"json","utf8",configBean.getAlipayPublicKey(),"RSA2");
		AlipayTradePayRequest alipay_request=new AlipayTradePayRequest();
		// 封装请求支付信息
		alipay_request.setBizContent("{" +
				"\"out_trade_no\":\""+orderNumber+"\"," +
				"\"scene\":\"bar_code\"," +
				"\"auth_code\":\""+authCode+"\"," +
				"\"subject\":\"美好生活家园收银\"," +
				"\"timeout_express\":\"2m\"," +
				"\"total_amount\":\""+amount+"\"" +
				"  }"); //设置业务参数
		AlipayTradePayResponse response = alipayClient.execute(alipay_request); //通过alipayClient调用API，获得对应的response类
		return response;
	}

	public static AlipayFundTransToaccountTransferResponse transfer(String code, String amount,String account,String name) throws Exception{
		try {
			Cache cache = staticCacheManager.getCache(GlobalStatic.cacheKey) ;
			ConfigBean configBean = cache.get(GlobalStatic.configCache, ConfigBean.class);
			AlipayClient alipayClient = new DefaultAlipayClient(configBean.getAlipayRefundUrl(),configBean.getAlipayAppId(),configBean.getAlipayPrivateKey(),"json","utf-8",configBean.getAlipayPublicKey(),"RSA2");
			AlipayFundTransToaccountTransferRequest request = new AlipayFundTransToaccountTransferRequest();
			request.setBizContent("{" +
					"\"out_biz_no\":\""+code+"\"," +
					"\"payee_type\":\"ALIPAY_LOGONID\"," +
					"\"payee_account\":\""+account+"\"," +
					"\"amount\":\""+amount+"\"," +
					"\"payee_real_name\":\""+name+"\"," +
					"\"remark\":\"【V云空间】提现\"" +
					"}");
			AlipayFundTransToaccountTransferResponse response = alipayClient.execute(request);
			return response;
		}catch (Exception e){
			e.printStackTrace();
		}
		return null;
	}
	
	
}

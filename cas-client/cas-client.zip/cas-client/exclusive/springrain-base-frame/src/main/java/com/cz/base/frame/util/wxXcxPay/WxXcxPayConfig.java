package com.cz.base.frame.util.wxXcxPay;

public class WxXcxPayConfig {
	/**
	 * 公众账号ID
	 */
	public static String appid = "wx2c3cde186bdd2312";
	//public static String appid = ;
	
	/**
	 * 
	 */
	public static String appsecret = "9be54922e321ccf533fad99c45d510cd";
	//public static String appsecret = ;
	
	/**
	 * 商户号（mch_id）
	 */
	public static String partner = "1495158672";
	
	public static String partnerkey = "jimohui123456789789654123jimohui";
	
	
	
	
	/**
	 * 回掉路径
	 */
	public static String notify_url="https://kecheng.dujialive.com/exclusive/system/payment/wxPayCallBack/json";
	/**
	 * 交易类型
	 */
	public static String trade_type = "JSAPI";//公众号支付
//	public static String trade_type2 = "NATIVE";//微信扫码支付
	
	public static String signType = "MD5";
}

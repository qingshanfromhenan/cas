package com.cz.base.frame.util;


import com.cz.base.frame.util.wxXcxPay.WxXcxPayConfig;
import com.cz.base.frame.util.wxap.util.ClientCustomSSL;
import com.cz.base.frame.util.wxap.util.MD5Util;
import com.cz.base.frame.util.wxap.util.XMLUtil;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;

import javax.servlet.http.HttpServletRequest;
import java.io.*;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.*;

public class WxPayUtils {

	public static Map transfer(String openid, String code, Double money, String name) throws Exception{
		//转换为整数
		String payMoney = new BigDecimal(money+"").movePointRight(2).toString();
		// 一次性字符串
		String nonce_str = UUID.randomUUID().toString().replaceAll("-", "");
		System.out.println(nonce_str);
		// IP
		String spbill_create_ip = "127.0.0.1";

		HashMap<String, String> map = new HashMap<String, String>();
		String appId = WxXcxPayConfig.appid;
		map.put("mch_appid", appId);
		map.put("mchid", WxXcxPayConfig.partner);
		map.put("nonce_str", nonce_str);
		map.put("desc", "V钻提现");  //"body", new String(body.getBytes("ISO-8859-1") ,"UTF-8")
		map.put("partner_trade_no", code);
		map.put("amount", payMoney);
		map.put("spbill_create_ip", spbill_create_ip);
		map.put("check_name", "NO_CHECK");
		map.put("openid", openid);
		String sign = sign(map, WxXcxPayConfig.partnerkey);//参数加密
		System.out.println("sign秘钥:-----------"+sign);
		map.put("sign", sign);

		// 生成需要提交给统一支付接口https://api.mch.weixin.qq.com/pay/unifiedorder
		// 的xml数据-------
		String xml = "<xml>" + "<mch_appid><![CDATA[" +appId + "]]></mch_appid>"
				+ "<mchid><![CDATA[" +WxXcxPayConfig.partner + "]]></mchid>"
				+ "<nonce_str><![CDATA[" + nonce_str + "]]></nonce_str>"
				+ "<partner_trade_no><![CDATA[" +  code + "]]></partner_trade_no>"
				+ "<openid><![CDATA[" + openid + "]]></openid>"
				+ "<check_name><![CDATA[NO_CHECK]]></check_name>"
				+ "<amount><![CDATA[" + payMoney + "]]></amount>"
				+ "<desc><![CDATA[" + "V钻提现" + "]]></desc>"
				+ "<spbill_create_ip><![CDATA[" + spbill_create_ip + "]]></spbill_create_ip>"
				+ "<sign><![CDATA[" + sign + "]]></sign>" + "</xml>";
		System.out.println("xml：" + xml);

		// 调用统一支付接口https://api.mch.weixin.qq.com/pay/unifiedorder 生产预支付订单
		String url = "https://api.mch.weixin.qq.com/mmpaymkttransfers/promotion/transfers";//微信统一订单接口
//		Map resultMap= sendPost(url, xml);//post方式访问微信统一订单接口,
		String result= ClientCustomSSL.doRefund(url, xml);
		System.out.println(result);
		Map resultMap = XMLUtil.doXMLParse(result) ;
		return resultMap;
	}



	
	/**
	 * 处理xml请求信息
	 * @param request
	 * @return
	 */
	public static String getXmlRequest(HttpServletRequest request){
		BufferedReader bis = null;
		String result = "";
		try{
			bis = new BufferedReader(new InputStreamReader(request.getInputStream()));
			String line = null;
			while((line = bis.readLine()) != null){
				result += line;
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			if(bis != null){
				try{
					bis.close();
				}catch(IOException e){
					e.printStackTrace();
				}
			}
		}
		return result;
	}
	


	/**
	 * 向指定 URL 发送POST方法的请求
	 * 
	 * @param url
	 *            发送请求的 URL
	 * @param param
	 *            请求参数，请求参数应该是 name1=value1&name2=value2 的形式。
	 * @return 所代表远程资源的响应结果
	 */
	public static Map sendPost(String url, String param) {
		PrintWriter out = null;
		BufferedReader in = null;
		System.out.println("post请求参数----------------------->" + param);
		String result = "";
		Map map = null;
		try {
			URL realUrl = new URL(url);
			// 打开和URL之间的连接
			HttpURLConnection conn =(HttpURLConnection) realUrl.openConnection();
			// 设置通用的请求属性
			conn.setRequestProperty("accept", "*/*");
			conn.setRequestProperty("connection", "Keep-Alive");
			conn.setRequestProperty("user-agent",
					"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
			// 发送POST请求必须设置如下两行
			conn.setDoOutput(true);
			conn.setDoInput(true);
			
			// 获取URLConnection对象对应的输出流
			//out = new PrintWriter(conn.getOutputStream());
			//out = new PrintWriter(new OutputStreamWriter(conn.getOutputStream(),"UTF-8"));
			out = new PrintWriter(new OutputStreamWriter(conn.getOutputStream(),"UTF-8"));
			// 发送请求参数
			out.print(param);
			// flush输出流的缓冲
			out.flush();
			// 定义BufferedReader输入流来读取URL的响应
			in = new BufferedReader(
					new InputStreamReader(conn.getInputStream()));
			String line;
			while ((line = in.readLine()) != null) {
				result += line;
			}

			result = new String(result.getBytes(),"utf-8");
			System.out.println(result);
			//JSONObject obj = JSONObject.fromObject(result);// 将json字符串转换为json对象

			try {
				map = doXMLParse(result);

			} catch (Exception e) {
				e.printStackTrace();
			}
			
		} catch (Exception e) {
			System.out.println("发送 POST 请求出现异常！" + e);
			e.printStackTrace();
		}
		// 使用finally块来关闭输出流、输入流
		finally {
			try {
				if (out != null) {
					out.close();
				}
				if (in != null) {
					in.close();
				}
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}

		return map;
	}
	
	
	
	
	
	
	
	
	
	/** 
     * 生成签名sign 
     * 第一步：非空参数值的参数按照参数名ASCII码从小到大排序，按照键值对的形式。生成字符串StringA 
     * stringA="appid=wxd930ea5d5a258f4f&body=test&device_info=1000&mch_id=10000100&nonce_str=ibuaiVcKdpRxkhJA"; 
     * 第二部：拼接API密钥，这里的秘钥是微信商户平台的秘钥，是自己设置的，不是公众号的秘钥 
     * stringSignTemp="stringA&key=192006250b4c09247ec02edce69f6a2d" 
     * 第三部：MD5加密 
     * sign=MD5(stringSignTemp).toUpperCase()="9A0A8659F005D6984697E2CA0A9CF3B7" 
     *  
     * @param map 不包含空字符串的map 
     * @return 
     */  
    public static String sign(Map<String, String> map, String key) {
        //排序  
        String sort=sortParameters(map);
        //拼接API秘钥  
        sort=sort+"&key="+key;  
        //System.out.println(sort);  
        //MD5加密  
        String sign= MD5Util.MD5Encode(sort, "UTF-8").toUpperCase() ;
        return sign;  
    }  
    
    /** 
     * 对参数列表进行排序，并拼接key=value&key=value形式 
     * @param map 
     * @return 
     */  
    private static String sortParameters(Map<String, String> map) {
        Set<String> keys = map.keySet();
        List<String> paramsBuf = new ArrayList<String>();
        for (String k : keys) {
            paramsBuf.add((k + "=" + getParamString(map, k)));  
        }  
        // 对参数排序  
        Collections.sort(paramsBuf);
        String result="";
        int count=paramsBuf.size();  
        for(int i=0;i<count;i++){  
            if(i<(count-1)){  
                result+=paramsBuf.get(i)+"&";  
            }else {  
                result+=paramsBuf.get(i);  
            }  
        }  
        return result;  
    }  
    /** 
     * 返回key的值 
     * @param map 
     * @param key 
     * @return 
     */  
    private static String getParamString(Map map, String key) {
        String buf = "";
        if (map.get(key) instanceof String[]) {
            buf = ((String[]) map.get(key))[0];
        } else {  
            buf = (String) map.get(key);
        }  
        return buf;  
    }  


	/**
	 * 解析xml,返回第一级元素键值对。如果第一级元素有子节点，则此节点的值是子节点的xml数据。
	 * 
	 * @param strxml
	 * @return
	 * @throws JDOMException
	 * @throws IOException
	 */
	public static Map doXMLParse(String strxml) throws Exception {
		if (null == strxml || "".equals(strxml)) {
			return null;
		}

		Map m = new HashMap();
		InputStream in = String2Inputstream(strxml);
		SAXBuilder builder = new SAXBuilder();
		Document doc = builder.build(in);
		Element root = doc.getRootElement();
		List list = root.getChildren();
		Iterator it = list.iterator();
		while (it.hasNext()) {
			Element e = (Element) it.next();
			String k = e.getName();
			String v = "";
			List children = e.getChildren();
			if (children.isEmpty()) {
				v = e.getTextNormalize();
			} else {
				v = getChildrenText(children);
			}

			m.put(k, v);
		}

		// 关闭流
		in.close();

		return m;
	}
	
	public static InputStream String2Inputstream(String str) {
		return new ByteArrayInputStream(str.getBytes());
	}
	/**
	 * 获取子结点的xml
	 * 
	 * @param children
	 * @return String
	 */
	public static String getChildrenText(List children) {
		StringBuffer sb = new StringBuffer();
		if (!children.isEmpty()) {
			Iterator it = children.iterator();
			while (it.hasNext()) {
				Element e = (Element) it.next();
				String name = e.getName();
				String value = e.getTextNormalize();
				List list = e.getChildren();
				sb.append("<" + name + ">");
				if (!list.isEmpty()) {
					sb.append(getChildrenText(list));
				}
				sb.append(value);
				sb.append("</" + name + ">");
			}
		}

		return sb.toString();
	}
	
	
	
	
	
	
}

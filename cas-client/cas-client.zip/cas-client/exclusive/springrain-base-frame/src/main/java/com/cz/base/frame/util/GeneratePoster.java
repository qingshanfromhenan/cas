package com.cz.base.frame.util;

import com.cz.base.frame.entity.ConfigBean;
import com.sun.image.codec.jpeg.JPEGCodec;
import com.sun.image.codec.jpeg.JPEGImageDecoder;
import com.sun.image.codec.jpeg.JPEGImageEncoder;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicHeader;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.imageio.ImageIO;
import javax.imageio.stream.ImageOutputStream;
import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.URL;
import java.util.Date;

/**
 * 二维码海报生成工具
 * @author jky
 * Created by Administrator on 2019/4/12.
 */
@Component
public class GeneratePoster {

    @Autowired
    CacheManager cacheManager ;
    public Logger logger = LoggerFactory.getLogger(getClass());

    private static CacheManager staticCacheManager ;

    @PostConstruct
    public void  init(){
        staticCacheManager = this.cacheManager ;
    }

   




    /**
     * 小程序二维码生成
     * @param productId
     * @param forwardUserId
     * @return  返回生成后的硬盘路径
     * @throws Exception
     */
    public static String createQRcode(Integer productId,Integer forwardUserId) throws Exception {
        // 微信生成二维码
        CloseableHttpClient httpclient = HttpClients.createDefault();

        // 创建httpget.
        String tokenurl = "https://api.weixin.qq.com/cgi-bin/token?appid=wx2c3cde186bdd2312&secret=9be54922e321ccf533fad99c45d510cd&grant_type=client_credential";
        HttpGet httpget = new HttpGet(tokenurl);
        // 执行get请求.
        CloseableHttpResponse httpResponse = httpclient.execute(httpget);
        HttpEntity tokenEntity = httpResponse.getEntity();
        JSONObject wxResult = null;
        if (tokenEntity != null) {
            String string = EntityUtils.toString(tokenEntity);
            wxResult = JSONObject.fromObject(string);
            System.out.println("*********************:" + string);
        }
        String token = null;
        if (wxResult == null || wxResult.containsKey("errcode")) {
            if (wxResult != null) {  // 记录失败信息
//                logger.error(wxResult.getString("errmsg"));
                System.out.println(wxResult.getString("errmsg"));
            }
            throw new Exception("授权失败");
        } else {
            token = wxResult.getString("access_token");
        }

        // 创建httppost.
        String url = "https://api.weixin.qq.com/wxa/getwxacodeunlimit?access_token=" + token;
        HttpPost httpPost = new HttpPost(url);

        // 创建参数队列
//		List<NameValuePair> formParams = new ArrayList<NameValuePair>();
        JSONObject params = new JSONObject();
        params.put("scene", productId+"_"+forwardUserId);
        params.put("width", 430);
        params.put("page", "pages/homepage/courseDetails/courseDetails");

        try {
            StringEntity s = new StringEntity(params.toString(), "utf-8");
            s.setContentEncoding(new BasicHeader(HTTP.CONTENT_TYPE,
                    "application/json"));
            httpPost.setEntity(s);
            httpPost.setHeader("content-type", "application/json");
            httpPost.addHeader("Authorization", "Basic YWRtaW46");
            CloseableHttpResponse response = httpclient.execute(httpPost);
            try {
                // 获取响应输入流
                InputStream inStream = response.getEntity().getContent();
                // 创建文件
                Cache cache = staticCacheManager.getCache(GlobalStatic.cacheKey) ;
                ConfigBean configBean = cache.get(GlobalStatic.configCache,ConfigBean.class) ;
                //实际上传的硬盘路径
                String realfilepath = configBean.getImgHardAddress() ;
                String dir = realfilepath+"/"+productId;
                String dirpath = null;
//                //上传文件的网络路径
//                String httppath=configBean.getPostImgAddress() ;
                if (dirpath != null) {
                    dir = dir + "/" + dirpath;
//                    httppath=httppath+"/"+dirpath;
                }
                int random=(int)(1+Math.random()*100);
                String randomName=String.valueOf(random);
                String filename = new Date().getTime() +randomName+ ".jpg";
                File f_dir=new File(dir);
                if(!f_dir.exists()){
                    f_dir.mkdirs();
                }


                File file = new File(dir+"/"+ filename);
                if(!file.exists()){
                    file.createNewFile();
                }

                FileOutputStream fos = new FileOutputStream(file);

                int len;
                byte[] buffer = new byte[1024];
                while ((len = inStream.read(buffer)) > 0){
                    fos.write(buffer, 0, len);
                }

                fos.close();
                inStream.close();
                return  dir+"/"+ filename ;
//                ByteArrayOutputStream baos = new ByteArrayOutputStream();
//                int len = 0;
//                byte[] b = new byte[1024];
//                while ((len = inStream.read(b, 0, b.length)) != -1) {
//                    baos.write(b, 0, len);
//                }
//                byte[] buffer = baos.toByteArray();
//                BASE64Encoder encoder = new BASE64Encoder();
//                String outstr = encoder.encode(buffer);
//                return "data:image/jpeg;base64," + outstr;
            } finally {
                response.close();
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // 关闭连接,释放资源
            try {
                httpclient.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return null;
    }


    /**
     * 绘制图片
     * * * @param headImg 用户头像（完整地址）
     * * @param nickname 用户昵称
     * * @param lessonName 课程名称
     * * @param qrcode 讲师二维码
     * * @param cover 课程封面图
     * * @return 绘制后的图片的路径
     */
    public static String drawImg(String headImg, String nickname, String lessonName,Integer productId,Integer userId,String phone) {
        Cache cache = staticCacheManager.getCache(GlobalStatic.cacheKey) ;
        ConfigBean configBean = cache.get(GlobalStatic.configCache,ConfigBean.class) ;
        BufferedInputStream is = null;
        OutputStream os = null;
        InputStream in = null;
        try {
            String path = "/webdata/haibaoDitu.jpg";//获取模板图片完整地址
            InputStream inputStream = new FileInputStream(new File(path));
            is = new BufferedInputStream(inputStream);//读取到模板图片流
            JPEGImageDecoder jpegDecoder = JPEGCodec.createJPEGDecoder(is);//通过JPEG图像流创建JPEG数据流解码器
            BufferedImage buffImg = jpegDecoder.decodeAsBufferedImage();//解码当前JPEG数据流，返回BufferedImage对象
            Graphics g = buffImg.getGraphics();//得到画笔对象
//            BufferedImage imgCover = getBufferedImage(null, "C:/Users/Administrator/Desktop/2x.png", 341 * 2, 255 * 2);
//            g.drawImage(imgCover, 0 + 30 + 4, 0 + 30 + 3, null);//将封面图绘制到模板图上
//            g.setColor(Color.BLACK);
//            BufferedImage img = getBufferedImage(headImg,null, 150, 150);;//把头像裁剪成正方形
            BufferedImage img = roundImg(headImg);;//把头像裁剪成圆形
            g.drawImage(img, 200, 120, null);//将头像绘制到模板图上
            g.setColor(Color.BLACK);
            Font f = new Font("PingFang SC Bold", Font.BOLD, 39);
            Color myColor = Color.WHITE;
            g.setColor(myColor);
            g.setFont(f);
//            FontMetrics fmNick = g.getFontMetrics(f);//昵称居中设置
//            int nickWidth = fmNick.stringWidth(nickname);
//            int nickWidthX = (190 - nickWidth) ;
//            g.drawString(nickname, nickWidthX, 402); //绘制文字
            FontMetrics fmLesson = g.getFontMetrics(f);//课程名称居中设置
            // 课程名称较长，还要进行换行处理，设置每14个字换行
            int batch = 10;
            int line = lessonName.length() / batch;
            if (lessonName.length() % batch != 0) line++;
            int begin = 0;
            int end = 10;
            int h = 0;//上下行间距30px
            int y = 338 ;  // 初始课程高度
            String lessonNameTmp = "";
            boolean isEnd = false;
            g.setColor(Color.white);
            for (int i = 0; i < line; i++) {
                if (lessonName.length() <= 10) {
                    //课程名称少于14个字
                    y=360;
                    int lessonWidth = fmLesson.stringWidth(lessonName);
                    int lessonWidthX = (480 - lessonWidth)/2;
                    g.drawString("《"+lessonName+"》", lessonWidthX, y);
                    break;
                }
                lessonNameTmp = lessonName.substring(begin, end);//每次截取14个字，把文字绘制到模板图上
                int lessonWidth = fmLesson.stringWidth(lessonNameTmp);
                int lessonWidthX = (480 - lessonWidth) /2;
                if (i == 0){
                    g.drawString("《"+lessonNameTmp, lessonWidthX, y);
                }else  if (i == line -1){
                    g.drawString(lessonNameTmp+"》", lessonWidthX, y);
                }else {
                    g.drawString(lessonNameTmp, lessonWidthX, y);
                }

                h += 50;
                y += 50;
                begin += batch;
                end += batch;
                if (isEnd) break;
                if (end > lessonName.length()) {
                    end = lessonName.length();
                    isEnd = true;
                }
            }
            f = new Font("PingFang SC Medium", Font.PLAIN, 25);
            g.setFont(f);
            g.drawString("邀请码:"+phone, 130, 445);
            String ewmPath = createQRcode(productId,userId);
//            String ewmPath = "C:/Users/Administrator/Desktop/21x.png";
            BufferedImage imgQrcode = getBufferedImage(null, ewmPath, 70 * 2 + 10, 70 * 2 + 10);
            g.drawImage(imgQrcode, 198, 530, null);//将讲师二维码绘制到模板图上
            g.setColor(Color.BLACK);
            g.dispose(); //把绘制好的图片写到下面这个图片里
            String realfilepath = configBean.getImgHardAddress() ;
//            String realfilepath = "/webdata/image/";
            String dir = realfilepath+"/"+productId;
            String dirpath = null;
//                //上传文件的网络路径
                String httppath=configBean.getPostImgAddress() ;
            if (dirpath != null) {
                dir = dir + "/" + dirpath;
                    httppath=httppath+"/"+dirpath;
            }
            int random=(int)(1+Math.random()*100);
            String randomName=String.valueOf(random);
            String filename = new Date().getTime() +randomName+ ".jpg";
            File f_dir=new File(dir);
            if(!f_dir.exists()){
                f_dir.mkdirs();
            }
//            os = new FileOutputStream("C:/Users/Administrator/Desktop/2.jpg");
            os = new FileOutputStream(dir+"/"+ filename);
            JPEGImageEncoder en = JPEGCodec.createJPEGEncoder(os);//创建编码器，用于编码内存中的图像数据
            en.encode(buffImg); //写完之后，再次读到这个图片
            return  httppath+"/"+productId+"/"+filename ;
//            return null;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (in != null) {
                    in.close();
                }
                if (os != null) {
                    os.close();
                }
                if (is != null) {
                    is.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return null;
    }


    /**
     * 改变图片尺寸
     *
     * @param imgUrl 图片的路径 domail + path
     * @param width  修改后的宽度
     * @param height 修改后的高度
     * @return 并返回BufferedImage对象
     */
    public static BufferedImage getBufferedImage(String imgUrl, String path, int width, int height) {
        if(StringUtils.isBlank(imgUrl) && StringUtils.isBlank(path)){
           return null;
        }
        try {
            BufferedImage bi = null;
            if (StringUtils.isNotBlank(path)) {
                bi = ImageIO.read(new File(path));
            }else  if (StringUtils.isNotBlank(imgUrl)) {
                bi = ImageIO.read(new URL(imgUrl));
            }
            BufferedImage tag = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
            tag.getGraphics().drawImage(bi, 0, 0, width, height, null);
            ByteArrayOutputStream bs = new ByteArrayOutputStream();
            ImageOutputStream imOut = ImageIO.createImageOutputStream(bs);
            ImageIO.write(tag, "jpg", imOut);
            InputStream is = new ByteArrayInputStream(bs.toByteArray());
            JPEGImageDecoder jpegDecoder = JPEGCodec.createJPEGDecoder(is);
            BufferedImage buffImg = jpegDecoder.decodeAsBufferedImage();
            return buffImg;

        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 把头像裁剪成圆形
     *
     * @param headImg 图片的完整地址 domail + path
     * @return 并返回BufferedImage对象
     */

    public static BufferedImage roundImg(String headImg) {
        if (StringUtils.isBlank(headImg)) {
            return null;
        }
        try {
            BufferedImage bi1 = ImageIO.read(new URL(headImg));
            BufferedImage bi2 = new BufferedImage(bi1.getWidth(), bi1.getHeight(), BufferedImage.TYPE_INT_ARGB);
            Ellipse2D.Double shape = new Ellipse2D.Double(0, 0, bi1.getWidth(), bi1.getHeight());
            Graphics2D g2 = bi2.createGraphics();
            bi2 = g2.getDeviceConfiguration().createCompatibleImage(bi1.getWidth(), bi1.getHeight(), Transparency.TRANSLUCENT);
            g2 = bi2.createGraphics();
//            g2.setBackground(Color.WHITE);
            g2.setComposite(AlphaComposite.Clear);
            g2.fill(new Rectangle(bi2.getWidth(), bi2.getHeight()));
            g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC, 1.0f));
            g2.setClip(shape); // 使用 setRenderingHint 设置抗锯齿
            g2.drawImage(bi1, 0, 0, null);
            g2.dispose();
            ByteArrayOutputStream bs = new ByteArrayOutputStream();
            ImageOutputStream imOut = ImageIO.createImageOutputStream(bs);
            ImageIO.write(bi2, "jpg", imOut);
            InputStream is = new ByteArrayInputStream(bs.toByteArray());
            JPEGImageDecoder jpegDecoder = JPEGCodec.createJPEGDecoder(is);
            BufferedImage buffImg = jpegDecoder.decodeAsBufferedImage();
            return buffImg;

        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }


    public static void main(String[] args) {
        drawImg("https://wx.qlogo.cn/mmopen/vi_32/DYAIOgq83erc5lBbRiciavTIOUGrKtnxicqzOrag7Xljaju55AHMdXwUqIXK78s6aVfhhedxoy1dEiaz220ibRJpO2w/132",
                "沉默","沉默的一课沉默的一课沉默的一课沉默的一课..",1,null,"18645447877");
    }


}

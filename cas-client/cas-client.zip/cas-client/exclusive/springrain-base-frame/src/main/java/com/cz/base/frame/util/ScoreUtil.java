package com.cz.base.frame.util;

import java.math.BigDecimal;

/**
 * 计算积分工具类
 * Created by Administrator on 2018/6/12 0012.
 */
public class ScoreUtil {

    /**
     * 计算积分
     * @param score 工单总得分
     * @param defScore  积分比例系数
     * @return
     * @throws Exception
     */
    public static  Integer getTotalScore(float score, float defScore)throws Exception{
        BigDecimal total = new BigDecimal("0");//	总积分
        total = new BigDecimal(score+"").multiply(new BigDecimal(defScore+"")).setScale(1,BigDecimal.ROUND_DOWN);
        return total.intValue();
    }
}

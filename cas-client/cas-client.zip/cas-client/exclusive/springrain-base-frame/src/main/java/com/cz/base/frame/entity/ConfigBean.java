package com.cz.base.frame.entity;

import java.io.Serializable;

public class ConfigBean implements Serializable{

	private static final long serialVersionUID = 1L;

	public ConfigBean() {
		super();
	}
	private String apiRSAPriKey ;     // 解密私钥
//	private String apiRSAPubKey;      // 加密公钥
	private String apiRSASignPubKey;   // 验签公钥
//	private String apiRSASignPriKey;   // 签名私钥
	private String apiDESKey ;    // 返回数据的解密密钥
	private String appId ;
	private String linkAndroid ;
	private String linkIos ;
	private String smsPassword ;
	private String smsExpire ;  // 短信验证码失效时间
	private String qqkey ;
	private String qqvalue ;
	private String rsaAlipayPublic ;
	private String rsaPrivate ;
	private String seller ;
	private String smsServiceURL ;
	private String smsUserId ;
	private String smsAccount ;
	private String umengAppkey ;
	private String weibokey ;
	private String weibovalue ;
	private String weixinkey ;
	private String weixinvalue ;
	private String tokenTimeout ;


	//支付宝支付
	private String alipayPartner;
	private String alipayKey;
	private String alipaySelller;
	private String alipayNotifyUrl;
	private String alipayRefundUrl;
	private String alipayAppId;
	private String alipayPrivateKey;
	private String alipayPublicKey;
	private String alipayCallBackUrl;

	//京东支付
	private String jdPrivateKey;
	private String jdPublicKey;
	private String jdPayUrl;
	private String jdRefundUrl;
	private String jdSuccessCallbackUrl;
	private String jdFailCallbackUrl;
	private String jdNotifyUrl;
	private String jdNum;
	private String jdDesKey;
	private String jdMd5Key;

	//微信支付
	private String wxpayPartner;
	private String wxpayAppId;
	private String wxpayAppSecret;
	private String wxpayPartnerKey;
	private String wxpayP12File;
	private String wxpayNotifyUrl ;


	private String smsType;
	private String aliAccessKeyId;
	private String aliAccessKeySecret;
	private String aliSmsProduct;
	private String aliSignName;

	//阿里云实名认证
	private String authenticationHost ;
	private String authenticationAppCode ;


	// 警报邮箱发件方信息
	private String alarmEmailAccout ; // 发件箱登录用户名
	private String alarmEmailAddress ;  // 发件箱邮箱
	private String alarmEmailPwd ;  // 发件箱密码
	private String alarmEmailSubject ; // 警报邮箱主题

	// 推送配置
	private String jpushEnvironment ;   // 推送环境  1开发环境 2生产环境
	private String jpushAppKey ;
	private String jpushAppMaster ;
	private String jpushSecondAppKey ;  // 第二个版本的key
	private String jpushSecondAppMaster ; // 第二个版本的master
	private String jpushThirdAppKey; //第三个版本key
	private String jpushThirdAppMaster; //第三个版本master

	//上传文件相关
	private String imgHardAddress ;
	private String postImgAddress ;

	//腾讯云通信
	private String tencentSdkAppId ;
	private String tencentIdentifier;
	private String tencentPrivateKey;

	private String easemobPrefix;
	private String tuzyTransfer ;

	public String getTuzyTransfer() {
		return tuzyTransfer;
	}

	public void setTuzyTransfer(String tuzyTransfer) {
		this.tuzyTransfer = tuzyTransfer;
	}

	public String getEasemobPrefix() {
		return easemobPrefix;
	}

	public void setEasemobPrefix(String easemobPrefix) {
		this.easemobPrefix = easemobPrefix;
	}

	public String getWxpayNotifyUrl() {
		return wxpayNotifyUrl;
	}

	public void setWxpayNotifyUrl(String wxpayNotifyUrl) {
		this.wxpayNotifyUrl = wxpayNotifyUrl;
	}

	public String getTencentSdkAppId() {
		return tencentSdkAppId;
	}

	public void setTencentSdkAppId(String tencentSdkAppId) {
		this.tencentSdkAppId = tencentSdkAppId;
	}

	public String getTencentIdentifier() {
		return tencentIdentifier;
	}

	public void setTencentIdentifier(String tencentIdentifier) {
		this.tencentIdentifier = tencentIdentifier;
	}

	public String getTencentPrivateKey() {
		return tencentPrivateKey;
	}

	public void setTencentPrivateKey(String tencentPrivateKey) {
		this.tencentPrivateKey = tencentPrivateKey;
	}

	public String getImgHardAddress() {
		return imgHardAddress;
	}

	public void setImgHardAddress(String imgHardAddress) {
		this.imgHardAddress = imgHardAddress;
	}

	public String getPostImgAddress() {
		return postImgAddress;
	}

	public void setPostImgAddress(String postImgAddress) {
		this.postImgAddress = postImgAddress;
	}

	public String getApiRSAPriKey() {
		return apiRSAPriKey;
	}

	public void setApiRSAPriKey(String apiRSAPriKey) {
		this.apiRSAPriKey = apiRSAPriKey;
	}


	public String getApiRSASignPubKey() {
		return apiRSASignPubKey;
	}

	public void setApiRSASignPubKey(String apiRSASignPubKey) {
		this.apiRSASignPubKey = apiRSASignPubKey;
	}


	public String getApiDESKey() {
		return apiDESKey;
	}

	public void setApiDESKey(String apiDESKey) {
		this.apiDESKey = apiDESKey;
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	public String getLinkAndroid() {
		return linkAndroid;
	}

	public void setLinkAndroid(String linkAndroid) {
		this.linkAndroid = linkAndroid;
	}

	public String getLinkIos() {
		return linkIos;
	}

	public void setLinkIos(String linkIos) {
		this.linkIos = linkIos;
	}

	public String getSmsPassword() {
		return smsPassword;
	}

	public void setSmsPassword(String smsPassword) {
		this.smsPassword = smsPassword;
	}

	public String getSmsExpire() {
		return smsExpire;
	}

	public void setSmsExpire(String smsExpire) {
		this.smsExpire = smsExpire;
	}

	public String getQqkey() {
		return qqkey;
	}

	public void setQqkey(String qqkey) {
		this.qqkey = qqkey;
	}

	public String getQqvalue() {
		return qqvalue;
	}

	public void setQqvalue(String qqvalue) {
		this.qqvalue = qqvalue;
	}

	public String getRsaAlipayPublic() {
		return rsaAlipayPublic;
	}

	public void setRsaAlipayPublic(String rsaAlipayPublic) {
		this.rsaAlipayPublic = rsaAlipayPublic;
	}

	public String getRsaPrivate() {
		return rsaPrivate;
	}

	public void setRsaPrivate(String rsaPrivate) {
		this.rsaPrivate = rsaPrivate;
	}

	public String getSeller() {
		return seller;
	}

	public void setSeller(String seller) {
		this.seller = seller;
	}

	public String getSmsServiceURL() {
		return smsServiceURL;
	}

	public void setSmsServiceURL(String smsServiceURL) {
		this.smsServiceURL = smsServiceURL;
	}

	public String getSmsUserId() {
		return smsUserId;
	}

	public void setSmsUserId(String smsUserId) {
		this.smsUserId = smsUserId;
	}

	public String getSmsAccount() {
		return smsAccount;
	}

	public void setSmsAccount(String smsAccount) {
		this.smsAccount = smsAccount;
	}

	public String getUmengAppkey() {
		return umengAppkey;
	}

	public void setUmengAppkey(String umengAppkey) {
		this.umengAppkey = umengAppkey;
	}

	public String getWeibokey() {
		return weibokey;
	}

	public void setWeibokey(String weibokey) {
		this.weibokey = weibokey;
	}

	public String getWeibovalue() {
		return weibovalue;
	}

	public void setWeibovalue(String weibovalue) {
		this.weibovalue = weibovalue;
	}

	public String getWeixinkey() {
		return weixinkey;
	}

	public void setWeixinkey(String weixinkey) {
		this.weixinkey = weixinkey;
	}

	public String getWeixinvalue() {
		return weixinvalue;
	}

	public void setWeixinvalue(String weixinvalue) {
		this.weixinvalue = weixinvalue;
	}

	public String getTokenTimeout() {
		return tokenTimeout;
	}

	public void setTokenTimeout(String tokenTimeout) {
		this.tokenTimeout = tokenTimeout;
	}


	public String getAlipayPartner() {
		return alipayPartner;
	}

	public void setAlipayPartner(String alipayPartner) {
		this.alipayPartner = alipayPartner;
	}

	public String getAlipayKey() {
		return alipayKey;
	}

	public void setAlipayKey(String alipayKey) {
		this.alipayKey = alipayKey;
	}

	public String getAlipaySelller() {
		return alipaySelller;
	}

	public void setAlipaySelller(String alipaySelller) {
		this.alipaySelller = alipaySelller;
	}

	public String getAlipayNotifyUrl() {
		return alipayNotifyUrl;
	}

	public void setAlipayNotifyUrl(String alipayNotifyUrl) {
		this.alipayNotifyUrl = alipayNotifyUrl;
	}

	public String getAlipayRefundUrl() {
		return alipayRefundUrl;
	}

	public void setAlipayRefundUrl(String alipayRefundUrl) {
		this.alipayRefundUrl = alipayRefundUrl;
	}

	public String getAlipayAppId() {
		return alipayAppId;
	}

	public void setAlipayAppId(String alipayAppId) {
		this.alipayAppId = alipayAppId;
	}

	public String getAlipayPrivateKey() {
		return alipayPrivateKey;
	}

	public void setAlipayPrivateKey(String alipayPrivateKey) {
		this.alipayPrivateKey = alipayPrivateKey;
	}

	public String getAlipayPublicKey() {
		return alipayPublicKey;
	}

	public void setAlipayPublicKey(String alipayPublicKey) {
		this.alipayPublicKey = alipayPublicKey;
	}

	public String getJdPrivateKey() {
		return jdPrivateKey;
	}

	public void setJdPrivateKey(String jdPrivateKey) {
		this.jdPrivateKey = jdPrivateKey;
	}

	public String getJdPublicKey() {
		return jdPublicKey;
	}

	public void setJdPublicKey(String jdPublicKey) {
		this.jdPublicKey = jdPublicKey;
	}

	public String getJdPayUrl() {
		return jdPayUrl;
	}

	public void setJdPayUrl(String jdPayUrl) {
		this.jdPayUrl = jdPayUrl;
	}

	public String getJdRefundUrl() {
		return jdRefundUrl;
	}

	public void setJdRefundUrl(String jdRefundUrl) {
		this.jdRefundUrl = jdRefundUrl;
	}

	public String getJdSuccessCallbackUrl() {
		return jdSuccessCallbackUrl;
	}

	public void setJdSuccessCallbackUrl(String jdSuccessCallbackUrl) {
		this.jdSuccessCallbackUrl = jdSuccessCallbackUrl;
	}

	public String getJdFailCallbackUrl() {
		return jdFailCallbackUrl;
	}

	public void setJdFailCallbackUrl(String jdFailCallbackUrl) {
		this.jdFailCallbackUrl = jdFailCallbackUrl;
	}

	public String getJdNotifyUrl() {
		return jdNotifyUrl;
	}

	public void setJdNotifyUrl(String jdNotifyUrl) {
		this.jdNotifyUrl = jdNotifyUrl;
	}

	public String getJdNum() {
		return jdNum;
	}

	public void setJdNum(String jdNum) {
		this.jdNum = jdNum;
	}

	public String getJdDesKey() {
		return jdDesKey;
	}

	public void setJdDesKey(String jdDesKey) {
		this.jdDesKey = jdDesKey;
	}

	public String getJdMd5Key() {
		return jdMd5Key;
	}

	public void setJdMd5Key(String jdMd5Key) {
		this.jdMd5Key = jdMd5Key;
	}

	public String getWxpayPartner() {
		return wxpayPartner;
	}

	public void setWxpayPartner(String wxpayPartner) {
		this.wxpayPartner = wxpayPartner;
	}

	public String getWxpayAppId() {
		return wxpayAppId;
	}

	public void setWxpayAppId(String wxpayAppId) {
		this.wxpayAppId = wxpayAppId;
	}

	public String getWxpayAppSecret() {
		return wxpayAppSecret;
	}

	public void setWxpayAppSecret(String wxpayAppSecret) {
		this.wxpayAppSecret = wxpayAppSecret;
	}

	public String getWxpayPartnerKey() {
		return wxpayPartnerKey;
	}

	public void setWxpayPartnerKey(String wxpayPartnerKey) {
		this.wxpayPartnerKey = wxpayPartnerKey;
	}

	public String getWxpayP12File() {
		return wxpayP12File;
	}

	public void setWxpayP12File(String wxpayP12File) {
		this.wxpayP12File = wxpayP12File;
	}

	public String getSmsType() {
		return smsType;
	}

	public void setSmsType(String smsType) {
		this.smsType = smsType;
	}

	public String getAliAccessKeyId() {
		return aliAccessKeyId;
	}

	public void setAliAccessKeyId(String aliAccessKeyId) {
		this.aliAccessKeyId = aliAccessKeyId;
	}

	public String getAliAccessKeySecret() {
		return aliAccessKeySecret;
	}

	public void setAliAccessKeySecret(String aliAccessKeySecret) {
		this.aliAccessKeySecret = aliAccessKeySecret;
	}

	public String getAliSmsProduct() {
		return aliSmsProduct;
	}

	public void setAliSmsProduct(String aliSmsProduct) {
		this.aliSmsProduct = aliSmsProduct;
	}

	public String getAliSignName() {
		return aliSignName;
	}

	public void setAliSignName(String aliSignName) {
		this.aliSignName = aliSignName;
	}

	public String getAuthenticationHost() {
		return authenticationHost;
	}

	public void setAuthenticationHost(String authenticationHost) {
		this.authenticationHost = authenticationHost;
	}

	public String getAuthenticationAppCode() {
		return authenticationAppCode;
	}

	public void setAuthenticationAppCode(String authenticationAppCode) {
		this.authenticationAppCode = authenticationAppCode;
	}

	public String getAlarmEmailAccout() {
		return alarmEmailAccout;
	}

	public void setAlarmEmailAccout(String alarmEmailAccout) {
		this.alarmEmailAccout = alarmEmailAccout;
	}

	public String getAlarmEmailAddress() {
		return alarmEmailAddress;
	}

	public void setAlarmEmailAddress(String alarmEmailAddress) {
		this.alarmEmailAddress = alarmEmailAddress;
	}

	public String getAlarmEmailPwd() {
		return alarmEmailPwd;
	}

	public void setAlarmEmailPwd(String alarmEmailPwd) {
		this.alarmEmailPwd = alarmEmailPwd;
	}

	public String getAlarmEmailSubject() {
		return alarmEmailSubject;
	}

	public void setAlarmEmailSubject(String alarmEmailSubject) {
		this.alarmEmailSubject = alarmEmailSubject;
	}

	public String getJpushEnvironment() {
		return jpushEnvironment;
	}

	public void setJpushEnvironment(String jpushEnvironment) {
		this.jpushEnvironment = jpushEnvironment;
	}

	public String getJpushAppKey() {
		return jpushAppKey;
	}

	public void setJpushAppKey(String jpushAppKey) {
		this.jpushAppKey = jpushAppKey;
	}

	public String getJpushAppMaster() {
		return jpushAppMaster;
	}

	public void setJpushAppMaster(String jpushAppMaster) {
		this.jpushAppMaster = jpushAppMaster;
	}

	public String getJpushSecondAppKey() {
		return jpushSecondAppKey;
	}

	public void setJpushSecondAppKey(String jpushSecondAppKey) {
		this.jpushSecondAppKey = jpushSecondAppKey;
	}

	public String getJpushSecondAppMaster() {
		return jpushSecondAppMaster;
	}

	public void setJpushSecondAppMaster(String jpushSecondAppMaster) {
		this.jpushSecondAppMaster = jpushSecondAppMaster;
	}

	public String getJpushThirdAppKey() {
		return jpushThirdAppKey;
	}

	public void setJpushThirdAppKey(String jpushThirdAppKey) {
		this.jpushThirdAppKey = jpushThirdAppKey;
	}

	public String getJpushThirdAppMaster() {
		return jpushThirdAppMaster;
	}

	public void setJpushThirdAppMaster(String jpushThirdAppMaster) {
		this.jpushThirdAppMaster = jpushThirdAppMaster;
	}
	
	public String getAlipayCallBackUrl() {
		return alipayCallBackUrl;
	}
	
	public void setAlipayCallBackUrl(String alipayCallBackUrl) {
		this.alipayCallBackUrl = alipayCallBackUrl;
	}
}

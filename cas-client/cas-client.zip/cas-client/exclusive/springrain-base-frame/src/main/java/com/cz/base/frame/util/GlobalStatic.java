package com.cz.base.frame.util;
/**
 * 全局的静态变量,用于全局变量的存放
 * @author springrain<Auto generate>
 * @version  2013-03-19 11:08:15
 */
public class GlobalStatic {
	public static  String rootDir=null;
	public static  String webInfoDir=null;
	public static  String staticHtmlDir=null;
	public static  String tempRootpath = System.getProperty("user.dir") + "/temp/";
	public static final int excelPageSize=1000;
	public static final  String suffix=".html";
	public static final String excelext=".xls";
	public static final String exportexcel="exportexcel";//是否是导出操作的key
	public static final String dataUpdate="更新";
	public static final String dataSave="保存";
	public static final String dataDelete="删除";
	public static final String luceneDir = "/webdata/project/lucene/index/" ;
//	public static final String luceneDir = "F:\\project\\lucene\\index\\" ;

	//page对象的缓存后缀key
	public static final String pageCacheExtKey="_springrain_page_key";
	
	//主业务缓存
	public static final String cacheKey="springraincache";
	//权限缓存
	public static final String qxCacheKey="springrainqxcache";
	//页面静态化缓存
	public static final String staticHtmlCacheKey="statichtmlcache";
	//登录次数校验缓存
	public static final String springrainloginCacheKey="springrainlogincache";
	//缓存用户最后有效的登陆sessionId
	public static final String springrainkeeponeCacheKey="springrainkeeponecache";
	//防火墙缓存
    public static final String springrainfirewallCacheKey="springrainfriewallcache";
	//微信缓存
   // public static final String springrainweixinCacheKey="springrainweixincache";
    //cms 缓存
    public static final String springraincmsCacheKey="springraincmscache";
    
    //defaultSiteId 缓存
    public static final String springraindefaultSiteId="defaultSiteId";

	//config表缓存
	public static final String configCache = "configData";
	//sysSysParam表缓存
	public static final String sysparamCache = "sysParamData";
	//订单编号序号值缓存
	public static final String SERIAL_NO = "serialNo";
	//警报邮件收件人
	public static final String ALARM_EMAIL = "alarmEmail" ;
	public static final String ALARM_EMAIL_TO = "alarmEmailTO" ;
	public static final String ALARM_EMAIL_CC = "alarmEmailCC" ;
	// 短信验证码
	public static final String smsCode = "smsCode_" ;  // 手机号收到的验证码
	public static final String smsLimitTime = "smsLimitTime_" ;


	/**
	 * 项目业务缓存，跟随项目需求不同进行变化
	 */
	public static final String PROJECT_CACHE = "projectCache" ;
	public static final String USERINFO_KEY = "userInfo_" ;   // 用户信息
	public static final String SUPPORT_KEY = "support:type" ;   // 点赞
	public static final String FOCUS = "focus:" ;   // 关注/收藏
	public static final String SIGNINHIS = "signInHis_" ;   // 连续签到时间段
	public static final String BLOCK_KEY = "blockList" ;
	public static final String HOUSE_STRUCTURE_KEY ="houseStructure_"; //房屋结构信息
	public static final String USERPAGE_KEY="userPage";          //用户页数信息
	public static final String PAGE_KEY="page";          //用户页数信息
	public static final String LEVEL = "leve" ;
	public static final String REG_TUZY = "REG_TUZY:" ;

	public static final String DIC_CREDIT_TYPE_KEY="dicCreditsType";   //积分来源信息
	public static final String DIC_COMMENT_SUPPORT_TYPE_KEY="commentSupportType_";   //评论点赞类型信息

	public static final String ALREADYRECOMMEND = "alreadyRecommend";  // 是否首页推荐过群组

	public static final String ANCHORROOMPAY = "anchorRoomPay:";  // 付费直播间用户是否付费




    //前后台传递的tokenKey
    public static final String tokenKey="springraintoken";
    //如果token错误,跳转地址的key
    public static final String errorTokentoURLKey="errorspringraintokentourlkey";
    //token错误跳转的页面
    public static final String errorTokentoURL="/errorpage/tokenerror";
    
    //自定义的登录地址key
    public static final String customLoginURLKey="customLoginURLKey";
    //自定义的token
    public static final String tokenCacheKey="tokenCache";
	//缓存用户最后有效的登陆sessionId
	public static final String keeponeCacheName="shiro-keepone-session";

    
	public static final String defaultCharset="UTF-8";
	
	public static final String tableSuffix="_history_";
	public static final String sysTableSuffix="_province_";
	public static final String frameTableAlias="frameTableAlias";
	public static final String returnDatas="returnDatas";
	

	//认证
	//public static final String reloginsession="shiro-reloginsession";
	//认证
	public static final String authenticationCacheName="shiro-authenticationCacheName";
	//授权
	public static final String authorizationCacheName="shiro-authorizationCacheName";
	//realm名称
	public static final String authorizingRealmName="shiroDbAuthorizingRealmName";


	//特殊账号的session的type以及账户id
	public static final String ACCOUT_TYP="accountType";
	public static final String ACCOUT_ID="accountId";

	//默认验证码参数名称
	public static final String DEFAULT_CAPTCHA_PARAM = "captcha";
	
	

	//密码连续错误10次,锁定不再进行登录查询,锁定 ERROR_LOGIN_LOCK_MINUTE  分钟
	public static final int ERROR_LOGIN_COUNT = 10;
	//错误登录后的,锁定分钟数
	public static final int ERROR_LOGIN_LOCK_MINUTE = 30;

	
	
	//同一IP防火墙阀值
	public static final Integer FRIEWALL_LOCK_COUNT = 10000;
	//同一IP阀值时间,单位是 秒
	public static final Integer FRIEWALL_LOCK_SECOND = 60;
	//锁定分钟数
	public static final Integer FRIEWALL_LOCKED_MINUTE = 10;

	//后台用户的分表信息
	public static final String SUBMETER="submeter";
	static{
		String path=Thread.currentThread().getContextClassLoader().getResource("").toString();
		path = path.replace("\\", "/");


		if(path.startsWith("file:/")){
			path=path.substring(6, path.length());
		}


		int _info=path.indexOf("/WEB-INF/classes");
		if(_info>0){
			path=path.substring(0, _info);
		}

		if(!path.startsWith("/")){
			path="/"+path;
		}

		rootDir=path;

		tempRootpath = rootDir + "/temp/";
		staticHtmlDir=rootDir + "/statichtml/";

	}

	
	

}

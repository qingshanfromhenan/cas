package com.cz.base.frame.util.wxap.util;

public class ConstantUtil {
	//收款方

	public static String spname = "微信支付接口测试";                                           

	//商户号
	public static String partner = "1302852701";

	//密钥
	public static String partner_key = "xingfuchengshidh179964770dhxfcsd";

	//appi
	public static String app_id= "wx1ecb6c1fa51e6fd3";

	public static String app_secret = "d4624c36b6795d1d99dcf0547af5443d";

	//appkey
	public static String app_key="L8LrMqqeGRxST5reouB0K66CaYAWpqhAVsq7ggKkxHCOastWksvuX1uvmvQclxaHoYd3ElNBrNO2DHnnzgfVG9Qs473M3DTOZug5er46FhuGofumV8H2FVR9qkjSlC5K";

//	//支付完成后的回调处理页面
//	public static String notify_url ="http://localhost/tenpay/payNotifyUrl.jsp";
	//调试模式
	boolean DEBUG_ = true;
}

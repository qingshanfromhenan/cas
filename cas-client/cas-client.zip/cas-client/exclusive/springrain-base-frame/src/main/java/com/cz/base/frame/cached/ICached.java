package com.cz.base.frame.cached;

import java.util.List;
import java.util.Set;


public interface ICached {
	/**
	 * 删除 缓存
	 * @param key
	 * @return
	 * @throws Exception
	 */
	String deleteCached(byte[] key)throws Exception;
	/**
	 * 更新 缓存
	 * @param key
	 * @param value
	 * @return
	 * @throws Exception
	 */
	Object updateCached(byte[] key, byte[] value, Long expire)throws Exception;
	/**
	 * 获取缓存
	 * @param key
	 * @return
	 * @throws Exception
	 */
	Object getCached(byte[] key)throws Exception;

	/**
	 * @desc:获取缓存
	 * @param key
	 * @param serialize  是否序列化value
	 * @return: java.lang.Object
	 * @auther: Michael Wong
	 * @email:  michael_wong@yunqihui.net
	 * @date:   2019/5/3 18:22
	 * @update:
	 */
	Object getCached(byte[] key, final boolean serialize)throws Exception;

	/**
	 * 根据 正则表达式key 获取 列表
	 * @param keys
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	Set getKeys(byte[] keys)throws Exception;

	/**
	 * 根据 正则表达式key 获取 列表
	 * @param keys
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	Set getHashKeys(byte[] key)throws Exception;

	/**
	 * @desc: hash是否存在map中的key
	 * @param key
	 * @param mapkey
	 * @return: java.lang.Boolean
	 * @auther: Michael Wong
	 * @email:  michael_wong@yunqihui.net
	 * @date:   2019/6/28 17:34
	 * @update:
	 */
	Boolean containsHashKeys(byte[] key,byte[] mapkey) throws Exception;

	/**
	 * 更新 缓存
	 * @param key
	 * @param value
	 * @return
	 * @throws Exception
	 */
	Boolean updateHashCached(byte[] key, byte[] mapkey, byte[] value, Long expire)throws Exception;


	/**
	 * 获取缓存
	 * @param key
	 * @return
	 * @throws Exception
	 */
	Object getHashCached(byte[] key, byte[] mapkey)throws Exception;


	/**
	 * 删除 缓存
	 * @param key
	 * @param value
	 * @return
	 * @throws Exception
	 */
	Long deleteHashCached(byte[] key, byte[] mapkey)throws Exception;

	/**
	 * 获取 map的长度
	 * @param key
	 * @return
	 * @throws Exception
	 */
	Long getHashSize(byte[] key)throws Exception;
/**
 * 获取 map中的所有值
 * @param key
 * @return
 * @throws Exception
 */
	@SuppressWarnings("rawtypes")
	List getHashValues(byte[] key)throws Exception;

	/**
	 * @desc:一个或多个值插入到列表头部,如果 key 不存在，一个空列表会被创建并执行 LPUSH 操作
	 * @param key
	 * @param values
	 * @return: java.lang.Long 列表的长度
	 * @auther: Michael Wong
	 * @email:  michael_wong@yunqihui.net
	 * @date:   2019/6/28 18:29       
	 * @update:        
	 */
	Long lpushList(byte[] key, byte[]... values) throws Exception;

	/**
	 * @desc: 移除LIST列表最后一个元素，并返回移除的元素内容
	 * @param key
	 * @return: java.lang.Object
	 * @auther: Michael Wong
	 * @email:  michael_wong@yunqihui.net
	 * @date:   2019/6/28 20:14
	 * @update:
	 */
	Object rpopList(byte[] key) throws Exception;
	/**
	 * 获取 map的长度
	 * @param key
	 * @return
	 * @throws Exception
	 */
	Long getDBSize()throws Exception;

	/**
	 * 获取 map的长度
	 * @param key
	 * @return
	 * @throws Exception
	 */
	void clearDB()throws Exception;

	/**
	 * @desc: 递增
	 * @param key
	 * @param step 步长
	 * @return: java.lang.Long
	 * @auther: Michael Wong
	 * @email:  michael_wong@yunqihui.net
	 * @date:   2019/5/3 11:35
	 * @update:
	 */
	Long incrBy(byte[] key, Long step)throws Exception;

	/**
	 * @desc: 递减
	 * @param key
	 * @param step 步长
	 * @return: java.lang.Long
	 * @auther: Michael Wong
	 * @email:  michael_wong@yunqihui.net
	 * @date:   2019/5/3 14:17
	 * @update:
	 */
	Long decrBy( byte[] key,  Long step)throws Exception ;

	/**
	 * @desc: 是否存在key
	 * @param key
	 * @return: java.lang.Boolean
	 * @auther: Michael Wong
	 * @email:  michael_wong@yunqihui.net
	 * @date:   2019/5/3 18:55
	 * @update:
	 */
	Boolean exsitKey(byte[] key)throws Exception;
}

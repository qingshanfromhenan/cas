package com.cz.base.frame.util.wxap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 *微信工具类
 */
@Component
public class WxpayUtil {
	@Autowired
	CacheManager cacheManager ;

	private static CacheManager staticCacheManager ;

	@PostConstruct
	public void  init(){
		staticCacheManager = this.cacheManager ;
	}


	/**
	 * 对支付宝回调参数进行解析
	 * @param requestParams
	 * @return
	 * @throws Exception
	 */
	public static Map<String, String> getNotifyParam(Map requestParams ) throws Exception{
		Map<String,String> params = new HashMap<String,String>();
		for (Iterator iter = requestParams.keySet().iterator(); iter.hasNext();) {
			String name = (String) iter.next();
			String[] values = (String[]) requestParams.get(name);
			String valueStr = "";
			for (int i = 0; i < values.length; i++) {
				valueStr = (i == values.length - 1) ? valueStr + values[i]
						: valueStr + values[i] + ",";
			}
			//乱码解决，这段代码在出现乱码时使用。如果mysign和sign不相等也可以使用这段代码转化
			//valueStr = new String(valueStr.getBytes("ISO-8859-1"), "gbk");
			if(!"id".equals(name)){
				params.put(name, valueStr);
			}
		}
		return params;
	}


}

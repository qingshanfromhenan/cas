package com.cz.base.frame.cached;

import org.springframework.data.redis.core.RedisTemplate;

import java.io.Serializable;

/**
 * Created by Administrator on 2019/3/29.
 */
public interface IRedisUtilService {

    public boolean set(final String key, Object value);


    /**
     * 写入缓存
     *  设置失效时间
     * @param key
     * @param value
     * @return
     */
    public boolean set(final String key, Object value, Long expireTime);
    /**
     * 读取缓存
     * @param key
     * @return
     */
    public Object get(final String key);

    /**
     * 删除对应的value
     * @param key
     */
    public void remove(final String key);

    /**
     * 批量删除对应的value
     *
     * @param keys
     */
    public void remove(final String... keys);

    /**
     * 批量删除key
     *
     * @param pattern 正则表达式
     */
    public void removePattern(final String pattern);

    /**
     * 判断缓存中是否有对应的value
     *
     * @param key
     * @return
     */
    public boolean exists(final String key);

    public  void setRedisTemplate(RedisTemplate<Serializable, Object> redisTemplate);
}

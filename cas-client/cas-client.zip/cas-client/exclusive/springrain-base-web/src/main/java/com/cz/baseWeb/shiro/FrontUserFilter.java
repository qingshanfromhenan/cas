package com.cz.baseWeb.shiro;

import org.apache.shiro.web.filter.authc.UserFilter;
import org.springframework.stereotype.Component;

/**
 * 前台用户的 过滤器，主要设置登陆界面
 * @author caomei
 *
 */


@Component("frontuser")
public class FrontUserFilter extends UserFilter {
	
	public FrontUserFilter(){
		//跳转到登录界面
		super.setLoginUrl("https://www.qingshanfrom.xyz:8443/cas/login?service=http://192.168.1.120:8080/exclusive/shiro-cas");
	}

}

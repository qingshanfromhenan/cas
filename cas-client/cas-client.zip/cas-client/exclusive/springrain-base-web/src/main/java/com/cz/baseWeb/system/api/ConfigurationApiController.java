package com.cz.baseWeb.system.api;

import com.cz.baseWeb.system.web.ConfigurationController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Created by Michael on 2017/4/28.
 */
@Controller
@RequestMapping(value="/app/configuration")
public class ConfigurationApiController extends ConfigurationController {

    /**
     * 配置信息列表
     *
     * @param request
     * @param model
     * @param configuration
     * @return configuration信息
     * @throws Exception
     */
//    @RequestMapping("/list/json")
//    @Override
//    public ReturnDatas listjson(HttpServletRequest request, Model model, Configuration configuration) throws Exception {
//        return super.listjson(request, model, configuration);
//    }
    /**
     * 配置信息详情
     * @param code
     * @return configuration信息
     * @throws Exception
     */
//    @RequestMapping(value = "/look/json")
//    @SecurityApi
//    @Override
//    public ReturnDatas lookjson(Model model, HttpServletRequest request, HttpServletResponse response) throws Exception {
//        return super.lookjson(model, request, response);
//    }
     /**
     * 配置信息列表
     *
     * @param request
     * @param model
     * @param configuration
     * @return 成功或者失败
     * @throws Exception
     */
//    @RequestMapping("/update")
//    @SecurityApi
//    @Override
//    public ReturnDatas saveorupdate(Model model, Configuration configuration, HttpServletRequest request, HttpServletResponse response) throws Exception {
//        return super.saveorupdate(model, configuration, request, response);
//    }

//    @SecurityApi
//    @Override
//    public ReturnDatas remoteUpdate(HttpServletRequest request, Model model, Configuration configuration) {
//        return super.remoteUpdate(request, model, configuration);
//    }
}

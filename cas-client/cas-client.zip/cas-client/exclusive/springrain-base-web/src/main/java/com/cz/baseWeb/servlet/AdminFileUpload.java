package com.cz.baseWeb.servlet;

import com.cz.base.frame.entity.ConfigBean;
import com.cz.base.frame.util.GlobalStatic;
import com.cz.base.frame.util.ReturnDatas;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.ProgressListener;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.Date;
import java.util.List;

/**
 * Servlet implementation class FileUpload
 */
public class AdminFileUpload extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Autowired(required = true)
	CacheManager cacheManager ;

	//前端自定义文件目录
	private static final String filepathdir = "filepathdir";
	
	//保存文件的文件夹名称
	private static final String uploadDirName="fungo";
	private static final String realpath="/usr/local/app/image/";
//	private static final String realfilepath= realpath+uploadDirName;
	//http地址
//	private static final String httppath="http://114.55.4.234:22222/image/";
//	private static final String httpfilepath=httppath+uploadDirName;
	//callback的url的key
	private static final String callbackurlName="callbackurl";
	
	// 1. 创建工厂类
	DiskFileItemFactory factory = new DiskFileItemFactory();
	// 2. 创建FileUpload对象
	ServletFileUpload upload = new ServletFileUpload(factory);

	public AdminFileUpload() {
		super();
		
		 //设置上传文件的最大值
		//upload. setFileSizeMax(1024000);
		
		// 上传进度
		upload.setProgressListener(new ProgressListener() {
			long num = 0;
			public void update(long bytesRead, long contentLength, int items) {
				long progress = bytesRead * 100 / contentLength;
				if (progress == num)
					return;
				num = progress;
				System.out.println("上传进度:" + progress + "%");
				// request.getSession().setAttribute("progress", progress);
			}
		});

	}

	/**
	 * 上传文件必须为POST方法
	 */
	@SuppressWarnings({ "static-access", "deprecation" })
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println(request.getSession().getServletContext().getRealPath(""));
		response.setContentType("text/html;charset=utf-8");
		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		PrintWriter out = response.getWriter();
		Integer userId = 0 ;
		if(request.getParameter("userId")!=null){
			userId = Integer.parseInt(request.getParameter("userId").toString());
		}
		ReturnDatas returnObject = ReturnDatas.getSuccessReturnDatas();
		
		// 3. 判断是否是上传表单
		boolean b = upload.isMultipartContent(request);
		if (!b) { // 不是文件上传
			return;
		}

		// 4. 解析request，获得FileItem项
		List<FileItem> fileitems = null;
		try {
			fileitems = upload.parseRequest(request);
		} catch (FileUploadException e) {
			e.printStackTrace();
		}
		if (fileitems == null) {
			return ;
		}
		// 创建文件
//		ServletContext context = getServletContext();
//		String dir = context.getRealPath("/")+"\\"+uploadDirName+"\\"+userId;
		Cache cache = cacheManager.getCache(GlobalStatic.cacheKey) ;
		ConfigBean configBean = cache.get(GlobalStatic.configCache,ConfigBean.class) ;
		//实际上传的硬盘路径
		String realfilepath = configBean.getImgHardAddress() ;
		String dir = realfilepath+"/"+userId;
		String dirpath = null;
//	    String httppath=httpfilepath;
		//上传文件的网络路径
	    String httppath=configBean.getPostImgAddress() ;
	    String callbackurl=null;

		System.out.println("realfilepath>>>>>>>>>>>>>>>>"+realfilepath);
		System.out.println("httppath>>>>>>>>>>>>>>>>"+httppath);
		// 5. 遍历集合,获取项目路径
		for (FileItem item : fileitems) {
			if(!item.isFormField()){
				continue;
			}
			if (callbackurlName.equals(item.getFieldName())) {//需要跳转的url
				callbackurl=item.getString();
			}else if (filepathdir.equals(item.getFieldName())) {
				if (item.getString().contains("\\.")) {// 包含路径.
					continue;
				}
				dirpath = item.getString();
			}
		}
		
//		if(callbackurl==null){
//			return;
//		}
		
		
		String allhttpfile="";

		if (dirpath != null) {
			dir = dir + "/" + dirpath;
			httppath=httppath+"/"+dirpath;
		}

		// 5. 遍历集合
		for (FileItem item : fileitems) {
			if (item.isFormField()) {// 普通字段
				continue;
			}
			
			// 获得文件名
			String filename = item.getName();
			String prefix=filename.substring(filename.lastIndexOf(".")+1);
//			filename = UUID.randomUUID().toString()+"."+prefix;
			filename = new Date().getTime() + "."+prefix;
			File f_dir=new File(dir);
			if(!f_dir.exists()){
				f_dir.mkdirs();
			}
			
			
			File file = new File(dir+"/"+ filename);
			if(!file.exists()){
				file.createNewFile();
			}
		
//			allhttpfile=allhttpfile+httppath+"/"+userId+"/"+filename+";";
//			urlList.add(httppath+"/"+userId+"/"+filename);
			// 获得流，读取数据写入文件
			InputStream in = item.getInputStream();
			FileOutputStream fos = new FileOutputStream(file);

			int len;
			byte[] buffer = new byte[1024];
			while ((len = in.read(buffer)) > 0){
				fos.write(buffer, 0, len);
			}

//			if (filename.contains(".png") || filename.contains(".jpg") || filename.contains(".jpeg")){
//				/**
//				 * 缩略图begin
//				 */
//				String smallDir = "sma" + filename ;
//				//added by yangkang 2016-3-30 去掉后缀中包含的.png字符串
//				if(smallDir.contains(".png")){
//					smallDir = smallDir.replace(".png", ".jpg");
//				}
//				long size = item.getSize();
//				double scale = 1.0d ;
//				if(size >= 200*1024){
//					scale = (200*1024f) / size  ;
//				}
//				//拼接文件路劲
//				String smallFilePathName = dir+"/" + smallDir;
//				try {
//					//added by chenshun 2016-3-22 注释掉之前长宽的方式，改用大小
////            Thumbnails.of(filePathName).size(width, height).toFile(thumbnailFilePathName);
//					if(size < 200*1024){
//						Thumbnails.of(dir+"/"+ filename).scale(1f).outputFormat("jpg").toFile(smallFilePathName);
//
//					}else{
//						Thumbnails.of(dir+"/"+ filename).scale(1f).outputQuality(0.8f).outputFormat("jpg").toFile(smallFilePathName);
//
//					}
//					allhttpfile=allhttpfile+httppath+"/"+userId+"/"+smallDir+";";
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//				/**
//				 * 缩略图end
//				 */
//			}else {
//			}
			allhttpfile=allhttpfile+httppath+"/"+userId+"/"+filename+";";



			
			fos.close();
			in.close();
			item.delete(); // 删除临时文件
		}
		
		if(allhttpfile.endsWith(";")){
			allhttpfile=allhttpfile.substring(0, allhttpfile.length()-1);
		}
		  out.print(allhttpfile);
	    System.out.println(allhttpfile);
	}

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		SpringBeanAutowiringSupport.processInjectionBasedOnServletContext(this,
				config.getServletContext());
	}
}

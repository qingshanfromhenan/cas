package com.cz.baseWeb.servlet;

import com.aliyun.oss.OSSClient;
import com.cz.base.frame.entity.ConfigBean;
import com.cz.base.frame.util.GlobalStatic;
import com.cz.base.frame.util.ReturnDatas;
import net.sf.json.JSONObject;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.ProgressListener;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Servlet implementation class FileUpload
 */
public class FileUpload extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Autowired(required = true)
	CacheManager cacheManager ;

	//前端自定义文件目录
	private static final String filepathdir = "filepathdir";

	//保存文件的文件夹名称
	private static final String uploadDirName="fungo";
	private static final String realpath="/usr/local/app/image/";
	//	private static final String realfilepath= realpath+uploadDirName;
	//http地址
//	private static final String httppath="http://114.55.4.234:22222/image/";
//	private static final String httpfilepath=httppath+uploadDirName;
	//callback的url的key
	private static final String callbackurlName="callbackurl";
	

	// 1. 创建工厂类
	DiskFileItemFactory factory = new DiskFileItemFactory();
	// 2. 创建FileUpload对象
	ServletFileUpload upload = new ServletFileUpload(factory);

	public FileUpload() {
		super();
		
		 //设置上传文件的最大值
		//upload. setFileSizeMax(1024000);
		
		// 上传进度
		upload.setProgressListener(new ProgressListener() {
			long num = 0;
			public void update(long bytesRead, long contentLength, int items) {
				long progress = bytesRead * 100 / contentLength;
				if (progress == num)
					return;
				num = progress;
				System.out.println("上传进度:" + progress + "%");
				// request.getSession().setAttribute("progress", progress);
			}
		});

	}

	/**
	 * 上传文件必须为POST方法
	 */
	@SuppressWarnings({ "static-access", "deprecation" })
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=utf-8");
		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		PrintWriter out = response.getWriter();
		Integer userId = 0 ;
		String location = "" ;
		String ext = "" ;
		// 判断userId
		if(request.getParameter("userId")!=null){
			userId = Integer.parseInt(request.getParameter("userId").toString());
		}
		// 判断location
		if(request.getParameter("location")!=null){
			location = request.getParameter("location").toString();
		}
		// 判断location
		if(request.getParameter("ext")!=null){
			ext = request.getParameter("ext").toString();
		}
		ReturnDatas returnObject = ReturnDatas.getSuccessReturnDatas();
		List<String> urlList = new ArrayList<String>();
		// 3. 判断是否是上传表单
		boolean b = upload.isMultipartContent(request);
		if (!b) { // 不是文件上传
			return;
		}

		// 4. 解析request，获得FileItem项
		List<FileItem> fileitems = null;
		try {
			fileitems = upload.parseRequest(request);
		} catch (FileUploadException e) {
			e.printStackTrace();
		}
		if (fileitems == null) {
			return ;
		}
		// 创建文件
		Cache cache = cacheManager.getCache(GlobalStatic.cacheKey) ;
		ConfigBean configBean = cache.get(GlobalStatic.configCache,ConfigBean.class) ;
		//实际上传的硬盘路径
		String realfilepath = configBean.getImgHardAddress() ;
		String dir = realfilepath+"/"+userId;
		String dirpath = null;
		//上传文件的网络路径
		String httppath=configBean.getPostImgAddress() ;
		String callbackurl=null;

		// 5. 遍历集合,获取项目路径
		for (FileItem item : fileitems) {
			if(!item.isFormField()){
				continue;
			}
			if (callbackurlName.equals(item.getFieldName())) {//需要跳转的url
				callbackurl=item.getString();
			}else if (filepathdir.equals(item.getFieldName())) {
				if (item.getString().contains("\\.")) {// 包含路径.
					continue;
				}
				dirpath = item.getString();
			}
		}

		
		String allhttpfile="";

		if (dirpath != null) {
			dir = dir + "/" + dirpath;
			httppath=httppath+"/"+dirpath;
		}

		// 5. 遍历集合
		for (FileItem item : fileitems) {
			if (item.isFormField()) {// 普通字段
				continue;
			}
			// 获得文件名
			String filename = item.getName();
			String prefix=filename.substring(filename.lastIndexOf(".")+1);


			if (StringUtils.isBlank(location) || "header".equals(location)){  // 头像上传,要放在本地服务器上

				int random=(int)(1+Math.random()*100);
				String randomName=String.valueOf(random);
				filename = new Date().getTime() +randomName+ "."+prefix;
				File f_dir=new File(dir);
				if(!f_dir.exists()){
					f_dir.mkdirs();
				}


				File file = new File(dir+"/"+ filename);
				if(!file.exists()){
					file.createNewFile();
				}

				// 获得流，读取数据写入文件
				InputStream in = item.getInputStream();
				FileOutputStream fos = new FileOutputStream(file);

				int len;
				byte[] buffer = new byte[1024];
				while ((len = in.read(buffer)) > 0){
					fos.write(buffer, 0, len);
				}

				if (filename.contains(".png") || filename.contains(".jpg") || filename.contains(".jpeg")){
					/**
					 * 缩略图begin
					 */
//				String smallDir = "sma" + filename ;
					String smallDir = filename ;
					//added by yangkang 2016-3-30 去掉后缀中包含的.png字符串
//				if(smallDir.contains(".png")){
//					smallDir = smallDir.replace(".png", ".jpg");
//				}
					long size = item.getSize();
					double scale = 1.0d ;
					if(size >= 200*1024){
						scale = (200*1024f) / size  ;
					}
					//拼接文件路劲
					String smallFilePathName = dir+"/" + smallDir;
					try {
						//added by chenshun 2016-3-22 注释掉之前长宽的方式，改用大小
//            Thumbnails.of(filePathName).size(width, height).toFile(thumbnailFilePathName);
				/*	if(size < 200*1024){
						Thumbnails.of(dir+"/"+ filename).scale(1f).outputFormat("jpg").toFile(smallFilePathName);

					}else{
						Thumbnails.of(dir+"/"+ filename).scale(1f).outputQuality(scale).outputFormat("jpg").toFile(smallFilePathName);

					}*/
						urlList.add(httppath+"/"+userId+"/"+smallDir);
					} catch (Exception e) {
						e.printStackTrace();
					}
					/**
					 * 缩略图end
					 */

				}else {
					urlList.add(httppath+"/"+userId+"/"+filename);
				}

				fos.close();
				in.close();
				item.delete(); // 删除临时文件

			}else {  // 上传阿里云oss
				// Endpoint以杭州为例，其它Region请按实际情况填写。
				String endpoint = "https://oss-cn-beijing-internal.aliyuncs.com";
				// 云账号AccessKey有所有API访问权限，建议遵循阿里云安全最佳实践，创建并使用RAM子账号进行API访问或日常运维，请登录 https://ram.console.aliyun.com 创建。
				String accessKeyId = "LTAI55pQQPWnlESr";
				String accessKeySecret = "S2YXYFpxAygECoMIU1caRnCXoT9Qkz";
				// 创建OSSClient实例。
				OSSClient ossClient = new OSSClient(endpoint, accessKeyId, accessKeySecret);
				// 上传文件流。
				try {
					InputStream inputStream = item.getInputStream();
					ossClient.putObject("province-"+ext, location + "/" + userId + "/" + filename, inputStream);
					urlList.add("https://province-"+ext+".oss-cn-beijing.aliyuncs.com/"+ location + "/" + userId + "/" + filename);
//					ossClient.shutdown();
				}catch (Exception e){
					e.printStackTrace();
				}finally {
					// 关闭OSSClient。
					ossClient.shutdown();
				}

			}
		}

		JSONObject json = new JSONObject();
		json.put("url",urlList);
		out.print(json.toString());
	    System.out.println(json.toString());
	}

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		SpringBeanAutowiringSupport.processInjectionBasedOnServletContext(this,
				config.getServletContext());
	}
}

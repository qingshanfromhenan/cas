package com.cz.baseWeb.system.web;

import com.cz.base.frame.controller.BaseController;
import com.cz.base.frame.util.*;
import com.cz.entity.*;
import com.cz.service.IUserOrgService;
import com.cz.service.IUserRoleMenuService;
import com.cz.service.IUserService;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.session.Session;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * 用户管理Controller,PC和手机浏览器用ACE自适应,APP提供JSON格式的数据接口
 * 
 * @copyright {@link 9iu.org}
 * @author 9iu.org<Auto generate>
 * @version 2014-06-26 11:36:47
 */
@Controller
@RequestMapping(value = "/system/user")
public class UserController extends BaseController {
	@Resource
	private IUserService userService;
	@Resource
	private IUserRoleMenuService userRoleMenuService ;
	@Resource
	private IUserOrgService userOrgService ;

	private String listurl = "/system/user/userList";

	/**
	 * 列表数据,调用listjson方法,保证和app端数据统一
	 * 
	 * @param request
	 * @param model
	 * @param user
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/list")
	public String list(HttpServletRequest request, Model model, User user)
			throws Exception {
		ReturnDatas returnObject = listjson(request, model, user);
		model.addAttribute(GlobalStatic.returnDatas, returnObject);
		return listurl;
	}

	/**
	 * json数据,为APP提供数据
	 * 
	 * @param request
	 * @param model
	 * @param user
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/list/json")
	public @ResponseBody
	ReturnDatas listjson(HttpServletRequest request, Model model, User user)
			throws Exception {
		ReturnDatas returnObject = ReturnDatas.getSuccessReturnDatas();
		Page page = newPage(request);
		
		String state=user.getState();
		if(StringUtils.isEmpty(state)){
//			user.setState("是");
		}
		List<User> datas = userService.findListDataByFinder(null, page,
				User.class, user);
		if (CollectionUtils.isNotEmpty(datas)){
			// 获取的role
			List<Role> roles = new ArrayList<>() ;
			// 获取org
			List<Org> orgs = new ArrayList<>();
			for (User data : datas) {
				roles = userRoleMenuService.findRoleByUserId(data.getId()) ;
				if (CollectionUtils.isNotEmpty(roles)) {
					StringBuffer roleNameBuffer = new StringBuffer();
					for (Role role : roles) {
						roleNameBuffer.append(role.getName() + ",") ;
					}
					data.setRoleName(roleNameBuffer.toString());
				}
				orgs = userOrgService.findOrgByUserId(data.getId());
				if (CollectionUtils.isNotEmpty(orgs)) {
					StringBuffer orgNameBuffer = new StringBuffer();
					for (Org org : orgs) {
						orgNameBuffer.append(org.getName() + ",") ;
					}
					data.setOrgName(orgNameBuffer.toString());
				}

			}


		}
		returnObject.setQueryBean(user);
		returnObject.setPage(page);
		returnObject.setData(datas);
		return returnObject;
	}

	
	/**
	 * 查看操作,调用APP端lookjson方法
	 */
	@RequestMapping(value = "/look")
	public String look(Model model, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		ReturnDatas returnObject = lookjson(model, request, response);
		model.addAttribute(GlobalStatic.returnDatas, returnObject);
		return "/system/user/userLook";
	}

	/**
	 * 查看的Json格式数据,为APP端提供数据
	 */
	@RequestMapping(value = "/look/json")
	public @ResponseBody
	ReturnDatas lookjson(Model model, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		ReturnDatas returnObject = ReturnDatas.getSuccessReturnDatas();
		String id = request.getParameter("id");
		if (StringUtils.isNotBlank(id)) {
			User user = userService.findUserById(id);
			Session session = SecurityUtils.getSubject().getSession();
			Object accountId = session.getAttribute(GlobalStatic.ACCOUT_ID);
		/*	String ext =(String) session.getAttribute(GlobalStatic.SUBMETER);
			if (accountId != null && StringUtils.isNotBlank(ext)){
				UserInfo userInfo=userInfoService.findUserInfoById(accountId,GlobalStatic.sysTableSuffix+ext);
				if (userInfo != null){
					user.setUserInfo(userInfo);
				}
			}*/
			returnObject.setData(user);
		} else {
			returnObject.setStatus(ReturnDatas.ERROR);
		}
		return returnObject;
	}

	/**
	 * 新增/修改 操作吗,返回json格式数据
	 * 
	 */
	@RequestMapping("/update")
	public @ResponseBody
	ReturnDatas saveorupdate(User user, HttpServletRequest request,HttpServletResponse response) throws Exception {
		ReturnDatas returnObject = ReturnDatas.getSuccessReturnDatas();
		returnObject.setMessage(MessageUtils.UPDATE_SUCCESS);

			String id = user.getId();
			String password = user.getPassword();

			String ext = SessionUser.getExt() ;
			user.setExt(ext);

			if (StringUtils.isBlank(password)) {  // 取默认密码
				user.setPassword(null);
			} else {
				user.setPassword(SecUtils.encoderByMd5With32Bit(password));
			}
			
			String[] roleIds=request.getParameterValues("roleIds");
			List<Role> listRole=null;
			if(roleIds!=null&&roleIds.length>0){
				Set<String> set=new HashSet<String>();
				for(String s:roleIds){
					if(StringUtils.isBlank(s)){
						continue;
					}else{
						if (("yw".equals(s) || "cszj".equals(s) || "xtzj".equals(s)) && roleIds.length>1)
							return new ReturnDatas(ReturnDatas.ERROR,"运维及专家只能选择一个角色") ;
					}
					set.add(s);
				}
				listRole=new ArrayList<Role>();
				for(String s2:set){
					Role role=new Role();
					role.setId(s2);
					listRole.add(role);
				}
			}
			user.setUserRoles(listRole);

		//处理管理的部门  韩彦阳   开始
		String orgIds = request.getParameter("orgIds");
		String[] managerOrgIds = orgIds.split(",") ;
		List<UserOrg> managerOrgs=null;
		if(managerOrgIds!=null){
			managerOrgs=new ArrayList<>();
			UserOrg managerOrg=null;
			for(int i=0;i<managerOrgIds.length;i++){
				managerOrg=new UserOrg();
				managerOrg.setOrgId(managerOrgIds[i]);
				managerOrg.setUserId(id);//可能为空，service中再补全
				managerOrgs.add(managerOrg);
			}
		}
		user.setManagerOrgs(managerOrgs);
		//处理管理的部门  韩彦阳  结束

			if (StringUtils.isBlank(id)) {
				user.setId(null);
				userService.saveUser(user);

			} else {
				user.setAccount(null);
				userService.updateUser(user);
			}
		return returnObject;
	}


	@RequestMapping("/updateInfo/json")
	public @ResponseBody
	ReturnDatas updateInfo(User user, HttpServletRequest request,HttpServletResponse response) throws Exception {
		ReturnDatas returnObject = ReturnDatas.getSuccessReturnDatas();
		returnObject.setMessage(MessageUtils.UPDATE_SUCCESS);
		Session session = SecurityUtils.getSubject().getSession();
		userService.update(user,true) ;
		return returnObject;
	}
	/**
	 * 进入修改页面,APP端可以调用 lookjson 获取json格式数据
	 */
	@RequestMapping(value = "/update/pre")
	public String edit(Model model, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		ReturnDatas returnObject = lookjson(model, request, response);
		model.addAttribute(GlobalStatic.returnDatas, returnObject);
		return "/user/userCru";
	}

	/**
	 * 删除操作
	 */
	@RequestMapping(value = "/delete")
	public @ResponseBody
	ReturnDatas destroy(HttpServletRequest request) throws Exception {
		// 执行删除
		try {
			String id = request.getParameter("id");
			
			if (StringUtils.isBlank(id)) {
				return new ReturnDatas(ReturnDatas.ERROR, "删除失败,用户Id不能为空!"); 
			}
			
		    userService.deleteUserById(id);
				
			
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return new ReturnDatas(ReturnDatas.ERROR, "删除失败!");
		}
		return  new ReturnDatas(ReturnDatas.SUCCESS, "用户删除成功!"); 
	}
	
	
	@RequestMapping(value = "/ajax/select2")
	public @ResponseBody List<User> ajaxUser(HttpServletRequest request) throws Exception {
		String key=request.getParameter("p");
		Page page=new Page();
		page.setPageIndex(1);
		

 		Finder finder= Finder.getSelectFinder(User.class, "id,name").append(" WHERE account like :account order by account asc ");
		finder.setParam("account", key+"%");
		
		return userService.queryForList(finder,User.class, page);
		
	}
	
	
	
	
}

package com.cz.baseWeb.system.api;

import com.cz.base.frame.annotation.ConversionApi;
import com.cz.base.frame.util.ReturnDatas;
import com.cz.baseWeb.system.web.SysSysparamController;
import com.cz.entity.SysSysparam;
import com.cz.service.ISysSysparamService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;


/**
 * @copyright {@link 9iu.org}
 * @author springrain<Auto generate>
 * @version  2017-03-21 15:09:49
 */
@Controller
@RequestMapping(value="/app/syssysparam")
public class SysSysparamApiController extends SysSysparamController {
	@Resource
	private ISysSysparamService sysSysparamService;

	/**
	 * json数据,为APP提供数据
	 *
	 * @param request
	 * @param model
	 * @param sysSysparam
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/list/json")
	@ConversionApi
	public @ResponseBody
	ReturnDatas listjson(HttpServletRequest request, Model model, SysSysparam sysSysparam) throws Exception{
		return super.listjson(request,model,sysSysparam);
	}



}

/**
 * appuser 页面使用javascript
 * @copyright {@link 9iu.org}
 * @author springrain<Auto generate>
 * @version  2017-02-24 15:17:23
 */


jQuery(document).ready(function(){
    //增加全选事件

});



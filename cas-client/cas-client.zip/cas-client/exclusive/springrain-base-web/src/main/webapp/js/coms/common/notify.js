// $(function(){
// 	var notifyInterval;
// 	var notifyNowBack;
// 	setInterval(function(){
// 		$.ajax({
//             url: ctx+'/system/notifyBean/notify/json',
// 			success:function(result){
// 				// console.log(result);
// 				$('#payed_medicineorder').html(result.data.unmedicineOrder);
// 				$('#payed_checkorder').html(result.data.uncheckOrder);
// 				$('#payed_returnorder').html(result.data.returnOrder);
//                 $('#payed_rewardreturn').html(result.data.unrewardOrder);
// 				if(result.data.unmedicineOrder > 0 || result.data.uncheckOrder > 0 || result.data.returnOrder > 0||result.data.unrewardOrder>0){
// 					if(!notifyInterval)
// 						notifyInterval = setInterval(function(){
// 							if(notifyNowBack=='#aaa') notifyNowBack = '#DD5A43';
// 							else notifyNowBack = '#aaa';
// 							$('#notify').css('background-color',notifyNowBack);
//
// 						},6000);
//                    // $('#sound').attr('src','http://app.huoguoli.com/hgl/sound/1.mp3');
//                     $('#sound').attr('src','http://wap.ctcdoc.com/sound/1.mp3');
// 				}else{
// 					clearInterval(notifyInterval);
// 					$('#notify').css('background-color','');
// 				}
//
//
// 			}
// 		});
//
// 	},30000);
// });